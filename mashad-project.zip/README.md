# Mash

Personal planner for Android: daily and weekly tasks with reminders, a per-day notepad,
the device calendar (every Google calendar synced to the phone, shared ones included) with a WhatsApp
export of the day's schedule, and a דמ"ח attendance board with a WhatsApp export.

The app has no internet permission. All data stays on the phone.

## Layout

- `web/` is the interface (plain HTML, CSS and JavaScript). `web/app.js` holds the code and `web/data.js` holds the starting settings (the app ships empty).
- `build_web.py` assembles `web/` into `android/app/src/main/assets/index.html`. Run it after changing anything in `web/`.
- `android/` is the Android project. The Java code hosts the page and gives it storage, calendar access,
  reminders and sharing.
- `android/mashad.keystore` signs every build with the same key, so a new version installs over the old one
  and keeps its data. 

## Building

With Android Studio: open the `android` folder, then Build > Build APK(s).

From a terminal with the Android SDK installed:

    cd android
    gradle assembleRelease

The APK is written to `android/app/build/outputs/apk/release/app-release.apk`.

On GitHub: every push to `main` builds the APK and publishes it under Releases.
