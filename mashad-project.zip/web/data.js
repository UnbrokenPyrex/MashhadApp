/* Starting data. The app ships empty; personal data is loaded on the phone through Settings > restore from backup. */
function seedState(){
  var ALL=[0,1,2,3,4,5,6];
  var pc=0;

  var tasks=[];
  var checklist=[];
  var standing=[];

  var statuses=[
    {name:'תורנות חוץ',present:true},{name:'נכנס פלסם',present:true},
    {name:'חפשש',present:false},{name:'גימלים',present:false},{name:'בקשצ',present:false},{name:'מיוחדת',present:false},
    {name:'רגילה',present:false},{name:'סבב קו',present:false},{name:'הפניה',present:false},{name:'קורס',present:false},
    {name:'כלא',present:false},{name:'חול',present:false},{name:'יום סידורים',present:false},{name:'יום ישיבה',present:false},
    {name:'רענון',present:false},{name:'אפטר',present:false},{name:'תמ"ל',present:false},{name:'אבל',present:false},
    {name:'חופש',present:false},{name:'ימי חופש',present:false},{name:'תש 2',present:false},{name:'תש פיקודי',present:false},
    {name:'כנס משתחררים',present:false},{name:'מעבר תפקיד',present:false}
  ];

  var platoons=[];

  return {
    v:2,updatedAt:0,
    tasks:tasks,done:{},
    checklist:checklist,checkDone:{},
    standing:standing,
    notes:{},generalNote:'',stars:{},
    platoons:platoons,statuses:statuses,pcount:pc,
    settings:{theme:'dark',notif:true,morning:'07:00',evening:'20:00',before:10,
      luzTitle:'לוז מ"פ',damachTitle:'',padHours:false,showEmptyReasons:false,
      calHide:{},calNoExport:{},lastCal:'',calView:'month',lang:'he',damachNext:true,splash:'מבצעית ג׳'}
  };
}
