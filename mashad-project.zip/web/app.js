(function(){
'use strict';
var NATIVE = typeof window.Android !== 'undefined';
var DAYS=['ראשון','שני','שלישי','רביעי','חמישי','שישי','שבת'];
var DL=['א׳','ב׳','ג׳','ד׳','ה׳','ו׳','ש׳'];
var DX=["א'","ב'","ג'","ד'","ה'","ו'",'שבת'];
var MONTHS=['ינואר','פברואר','מרץ','אפריל','מאי','יוני','יולי','אוגוסט','ספטמבר','אוקטובר','נובמבר','דצמבר'];
var ALL=[0,1,2,3,4,5,6];
var RLM='‏';

var I={
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  chev:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
  edit:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg>',
  plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  send:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12l16-8-6 16-3-6.5L4 12z"/></svg>',
  sun:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/></svg>',
  cal:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  list:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6l1.5 1.5L8 5M11.5 6.2H20M4 12l1.5 1.5L8 11M11.5 12.2H20M4 18l1.5 1.5L8 17M11.5 18.2H20"/></svg>',
  people:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17.2" cy="9" r="2.5"/><path d="M16.5 14.2c2.6.4 4.5 2.7 4.5 5.8"/></svg>',
  gear:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h9M19 7h1M4 17h1M11 17h9"/><circle cx="16" cy="7" r="2.6"/><circle cx="8" cy="17" r="2.6"/></svg>'
};

/* ---------- small helpers ---------- */
function $(s,r){return (r||document).querySelector(s);}
function pad(n){return (n<10?'0':'')+n;}
function ymd(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
function pd(s){var a=s.split('-');return new Date(+a[0],+a[1]-1,+a[2]);}
function addDays(s,n){var d=pd(s);d.setDate(d.getDate()+n);return ymd(d);}
function dow(s){return pd(s).getDay();}
function dm(s){var d=pd(s);return d.getDate()+'/'+(d.getMonth()+1);}
function weekStart(s){return addDays(s,-dow(s));}
function todayStr(){return ymd(new Date());}
function dayName(s){var w=dow(s);return w===6?'שבת':'יום '+DAYS[w];}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function uid(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function clone(o){return JSON.parse(JSON.stringify(o));}
function find(arr,id){for(var i=0;i<arr.length;i++)if(arr[i].id===id)return arr[i];return null;}
function cleanName(s){return String(s||'').replace(/[⁠‎‏‪-‮﻿]/g,'').replace(/\s+/g,' ').trim();}
function hash(s){var h=7;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h)%2000000000+1;}
function timeAt(ds,hm){var d=pd(ds),a=hm.split(':');d.setHours(+a[0],+a[1],0,0);return d.getTime();}

/* ---------- bridge to the phone (or a stand-in when previewed in a browser) ---------- */
var mock={events:null,cals:[{id:'1',name:'לו"ז מ"פ',account:'דוגמה',color:'#e3120b',canWrite:true,synced:true},{id:'2',name:'אישי',account:'דוגמה',color:'#888888',canWrite:true,synced:true}]};
function mockEvents(){
  if(mock.events)return mock.events;
  var t=todayStr();
  mock.events=[
    {id:'m1',calId:'1',title:'תדריך בוקר',begin:timeAt(t,'08:00'),end:timeAt(t,'08:30'),allDay:false,loc:'חדר ישיבות',desc:'כל הצוות',recurring:false},
    {id:'m2',calId:'1',title:'ישיבת צוות',begin:timeAt(addDays(t,1),'14:00'),end:timeAt(addDays(t,1),'15:00'),allDay:false,loc:'',desc:'',recurring:true}
  ];
  return mock.events;
}
var B = NATIVE ? {
  load:function(){return window.Android.loadState();},
  save:function(s){window.Android.saveState(s);},
  share:function(t,wa){window.Android.share(t,!!wa);},
  copy:function(t){window.Android.copy(t);},
  calPerm:function(){return window.Android.hasCalendarPermission();},
  reqCal:function(){window.Android.requestCalendarPermission();},
  calendars:function(){try{return JSON.parse(window.Android.listCalendars());}catch(e){return [];}},
  calError:function(){try{return window.Android.calendarError()||'';}catch(e){return '';}},
  events:function(a,b){try{return JSON.parse(window.Android.getEvents(String(a),String(b)));}catch(e){return [];}},
  insertEvent:function(o){return window.Android.insertEvent(JSON.stringify(o));},
  updateEvent:function(o){return window.Android.updateEvent(JSON.stringify(o));},
  deleteEvent:function(id){return window.Android.deleteEvent(String(id));},
  deleteInstance:function(e){return window.Android.deleteInstance(String(e.id),String(e.begin));},
  openEvent:function(e){window.Android.openEvent(String(e.id),String(e.begin),String(e.end));},
  schedule:function(list){window.Android.scheduleAlarms(JSON.stringify(list));},
  notifOk:function(){return window.Android.notificationsEnabled();},
  reqNotif:function(){window.Android.requestNotificationPermission();},
  notifSettings:function(){window.Android.openNotificationSettings();},
  testNotif:function(){window.Android.testNotification();},
  exactOk:function(){return window.Android.canScheduleExact();}
} : {
  load:function(){try{return localStorage.getItem('mashad-state');}catch(e){return null;}},
  save:function(s){try{localStorage.setItem('mashad-state',s);}catch(e){}},
  share:function(t){B.copy(t);},
  copy:function(t){try{navigator.clipboard.writeText(t);}catch(e){}},
  calPerm:function(){return true;},
  reqCal:function(){},
  calendars:function(){return mock.cals;},
  calError:function(){return '';},
  events:function(a,b){return mockEvents().filter(function(e){return e.end>a&&e.begin<b;});},
  insertEvent:function(o){o.id=uid('m');o.recurring=false;mockEvents().push(o);return o.id;},
  updateEvent:function(o){var e=find(mockEvents(),o.id);if(e)for(var k in o)e[k]=o[k];return 'ok';},
  deleteEvent:function(id){mock.events=mockEvents().filter(function(e){return e.id!==id;});return 'ok';},
  deleteInstance:function(e){return B.deleteEvent(e.id);},
  openEvent:function(){},
  schedule:function(){},
  notifOk:function(){return true;},
  reqNotif:function(){},
  notifSettings:function(){},
  testNotif:function(){toast('באפליקציה תופיע כאן התראת בדיקה');},
  exactOk:function(){return true;}
};

/* ---------- state ---------- */
var state=null;
function normalize(st){
  var d=seedState();
  if(!st||!st.tasks||!st.platoons)return d;
  ['done','checkDone','notes'].forEach(function(k){if(!st[k])st[k]={};});
  ['checklist','standing','statuses'].forEach(function(k){if(!st[k])st[k]=d[k];});
  if(!st.settings)st.settings=d.settings;
  for(var k in d.settings)if(st.settings[k]===undefined)st.settings[k]=d.settings[k];
  ['calHide','calNoExport'].forEach(function(k){if(!st.settings[k])st.settings[k]={};});
  if(st.generalNote==null)st.generalNote='';
  st.platoons.forEach(function(pl){if(!pl.groups)pl.groups=[];if(!pl.people)pl.people=[];});
  st.tasks.forEach(function(t){if(!t.days)t.days=[];if(!t.foot)t.foot=[];});
  return st;
}
(function(){
  var raw=null,st=null;try{raw=B.load();}catch(e){}
  try{st=raw?JSON.parse(raw):null;}catch(e){st=null;}
  state=normalize(st);
})();
var S=state.settings;
var alarmTimer=null;
function save(){
  state.updatedAt=Date.now();
  B.save(JSON.stringify(state));
  clearTimeout(alarmTimer);alarmTimer=setTimeout(pushAlarms,800);
}
function prune(){
  var cut=addDays(todayStr(),-60);
  ['done','checkDone'].forEach(function(k){Object.keys(state[k]).forEach(function(d){if(d<cut)delete state[k][d];});});
}

var ui={tab:'day',date:todayStr(),open:null,seg:'tasks',plOpen:{},q:''};
var lastToday=todayStr();

/* ---------- tasks ---------- */
function occurs(t,ds){
  if(t.rep==='none')return t.date===ds;
  if(t.until&&ds>t.until)return false;
  if(t.from&&ds<t.from)return false;
  return t.days.indexOf(dow(ds))>=0;
}
function tasksOn(ds){
  return state.tasks.map(function(t,i){return [t,i];}).filter(function(p){return occurs(p[0],ds);})
    .sort(function(a,b){var x=a[0].time||'',y=b[0].time||'';return x<y?-1:x>y?1:a[1]-b[1];})
    .map(function(p){return p[0];});
}
function isDone(ds,id){return !!(state.done[ds]&&state.done[ds][id]);}
function toggleDone(ds,id){var m=state.done[ds]||(state.done[ds]={});if(m[id])delete m[id];else m[id]=1;save();}
function dayCount(ds){var l=tasksOn(ds),n=0;l.forEach(function(t){if(isDone(ds,t.id))n++;});return [n,l.length];}
function carryOver(){
  var t=todayStr(),out=[];
  for(var i=14;i>=1;i--){var ds=addDays(t,-i);tasksOn(ds).forEach(function(k){
    if(k.rep!=='none'&&(k.days.length===7||i>6))return;
    if(!isDone(ds,k.id))out.push([k,ds]);
  });}
  return out;
}
function timeLabel(t){return t.time?(t.end?t.time+'–'+t.end:t.time):'';}
function daysLabel(t){
  if(t.rep==='none')return t.date?dayName(t.date)+' '+dm(t.date):'';
  if(t.days.length===7)return 'כל יום';
  return t.days.slice().sort().map(function(d){return DL[d];}).join(' ');
}
function wkKey(){return weekStart(todayStr());}
function cDone(id){var w=state.checkDone[wkKey()];return !!(w&&w[id]);}
function cToggle(id){var w=state.checkDone[wkKey()]||(state.checkDone[wkKey()]={});if(w[id])delete w[id];else w[id]=1;save();}
function checkCount(){var n=0;state.checklist.forEach(function(c){if(cDone(c.id))n++;});return [n,state.checklist.length];}

/* ---------- notifications ---------- */
function buildAlarms(){
  if(!S.notif)return [];
  var out=[],now=Date.now(),t0=todayStr();
  for(var i=0;i<14;i++){
    var ds=addDays(t0,i),list=tasksOn(ds);
    var open=list.filter(function(t){return !isDone(ds,t.id);});
    open.forEach(function(t){
      if(!t.time||t.remind===false)return;
      var before=(t.before==null?S.before:t.before)||0;
      var at=timeAt(ds,t.time)-before*60000;
      if(at>now)out.push({id:hash('t'+t.id+ds),at:at,title:t.title,text:(before?'בעוד '+before+' דק׳ · ':'')+timeLabel(t)+(t.note?' · '+t.note:'')});
    });
    if(S.morning&&list.length){
      var am=timeAt(ds,S.morning);
      if(am>now)out.push({id:hash('m'+ds),at:am,title:'משימות ל'+dayName(ds)+' ('+list.length+')',text:list.map(function(t){return (t.time?t.time+' ':'')+t.title;}).join(' · ')});
    }
    if(S.evening){
      var pm=timeAt(ds,S.evening);
      if(pm>now){
        if(i===0){if(open.length)out.push({id:hash('e'+ds),at:pm,title:'נשארו '+open.length+' משימות פתוחות',text:open.map(function(t){return t.title;}).join(' · ')});}
        else if(list.length)out.push({id:hash('e'+ds),at:pm,title:'סיכום יום',text:'לבדוק מה נשאר פתוח מתוך '+list.length+' המשימות של היום'});
      }
    }
  }
  out.sort(function(a,b){return a.at-b.at;});
  return out.slice(0,300);
}
function pushAlarms(){try{B.schedule(buildAlarms());}catch(e){}}

/* ---------- calendar ---------- */
function calList(){return B.calPerm()?B.calendars():[];}
function isoDay(ms){return new Date(ms).toISOString().slice(0,10);}
function eventsByDay(from,toExcl){
  var map={};
  if(!B.calPerm())return map;
  var ev=B.events(pd(from).getTime(),pd(toExcl).getTime())||[];
  ev.forEach(function(e){
    if(S.calHide[e.calId])return;
    var st,en;
    if(e.allDay){st=isoDay(e.begin);en=isoDay(e.end);if(en<=st)en=addDays(st,1);}
    else{st=ymd(new Date(e.begin));en=addDays(ymd(new Date(Math.max(e.begin,e.end-1))),1);}
    for(var d=st<from?from:st;d<en&&d<toExcl;d=addDays(d,1))(map[d]||(map[d]=[])).push(e);
  });
  Object.keys(map).forEach(function(d){map[d].sort(function(x,y){return (y.allDay?1:0)-(x.allDay?1:0)||x.begin-y.begin;});});
  return map;
}
function eventsOn(ds,forExport){
  var l=eventsByDay(ds,addDays(ds,1))[ds]||[];
  return forExport?l.filter(function(e){return !S.calNoExport[e.calId];}):l;
}
function ft(ms){var d=new Date(ms);return (S.padHours?pad(d.getHours()):d.getHours())+':'+pad(d.getMinutes());}
function hm(ms){var d=new Date(ms);return pad(d.getHours())+':'+pad(d.getMinutes());}
function plain(s){return String(s||'').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>');}
function peopleOf(e){var l=plain(e.desc).split('\n').map(function(x){return x.trim();}).filter(Boolean);return l[0]||'';}
function luzText(ds){
  var ev=eventsOn(ds,true);
  var out=['> '+RLM+S.luzTitle+' '+dayName(ds)+' '+dm(ds)+':'];
  if(!ev.length)out.push('','אין אירועים');
  ev.forEach(function(e){
    out.push('');
    out.push(RLM+(e.allDay?'כל היום':ft(e.begin)+' - '+ft(e.end))+' | '+(e.title||'(ללא כותרת)'));
    var p=peopleOf(e);
    if(p)out.push(RLM+(/^\(.*\)$/.test(p)?p:'('+p+')'));
    if(e.loc)out.push('📍'+e.loc);
  });
  return out.join('\n');
}

/* ---------- דמ"ח ---------- */
function stOf(name){for(var i=0;i<state.statuses.length;i++)if(state.statuses[i].name===name)return state.statuses[i];return null;}
function isPresent(p){if(!p.status)return true;var s=stOf(p.status);return !!(s&&s.present);}
function plCount(pl){var n=0;pl.people.forEach(function(p){if(isPresent(p))n++;});return [n,pl.people.length];}
function totals(){var a=0,b=0;state.platoons.forEach(function(pl){var c=plCount(pl);a+=c[0];b+=c[1];});return [a,b];}
function pLabel(p,withUntil){var x=[];if(p.note)x.push(p.note);if(withUntil&&p.until)x.push('עד '+dm(p.until));return p.name+(x.length?' ('+x.join(', ')+')':'');}
function damachWarnings(){
  var t=todayStr(),w={unchecked:[],overdue:[],dups:[]};
  var seen={};
  state.platoons.forEach(function(pl){
    if(pl.checked!==t&&pl.people.length)w.unchecked.push(pl.short||pl.name);
    pl.people.forEach(function(p){
      if(!isPresent(p)&&p.until&&p.until<t)w.overdue.push(p.name+' ('+p.status+' עד '+dm(p.until)+')');
      var k=cleanName(p.name);if(seen[k]&&seen[k]!==pl.id)w.dups.push(p.name);else seen[k]=pl.id;
    });
  });
  return w;
}
function damachText(ds){
  var out=[],tt=totals();
  out.push('> דמ״ח '+(dow(ds)===6?'שבת':'יום '+DX[dow(ds)])+' '+dm(ds)+(S.damachTitle?' '+S.damachTitle:''));
  state.platoons.forEach(function(pl){var c=plCount(pl);out.push('*'+(pl.short||pl.name)+'* '+c[0]+'/'+c[1]);});
  out.push('*סה״כ* '+tt[0]+'/'+tt[1]);
  state.platoons.forEach(function(pl){
    var c=plCount(pl);
    out.push('','');
    out.push('*'+pl.name+(pl.commander?' - '+pl.commander:'')+'*');
    out.push('נוכחים: '+c[0]+'/'+c[1]);
    var base=pl.people.filter(function(p){return !p.status;});
    function numbered(label,list){
      if(!list.length)return;
      out.push('');
      if(label)out.push('*'+label+'*');
      list.forEach(function(p,i){out.push((i+1)+'. '+pLabel(p));});
    }
    if(pl.groups&&pl.groups.length){
      pl.groups.forEach(function(g){numbered(g,base.filter(function(p){return p.group===g;}));});
      numbered(pl.baseLabel||'נוכחים',base.filter(function(p){return pl.groups.indexOf(p.group)<0;}));
    }else numbered(pl.baseLabel,base);
    state.statuses.filter(function(s){return s.present;}).forEach(function(s){
      numbered(s.name,pl.people.filter(function(p){return p.status===s.name;}));
    });
    var lines=[],known={};
    state.statuses.forEach(function(s){
      known[s.name]=1;if(s.present)return;
      var l=pl.people.filter(function(p){return p.status===s.name;});
      if(l.length||S.showEmptyReasons)lines.push('*'+s.name+'-* '+l.map(function(p){return pLabel(p,true);}).join(', '));
    });
    pl.people.forEach(function(p){if(p.status&&!known[p.status]){known[p.status]=1;lines.push('*'+p.status+'-* '+pl.people.filter(function(q){return q.status===p.status;}).map(function(q){return pLabel(q,true);}).join(', '));}});
    if(lines.length){out.push('');lines.forEach(function(l){out.push(l.replace(/\s+$/,''));});}
  });
  return out.join('\n');
}
function parseNames(text){
  return String(text||'').split(/[\n,]+/).map(function(l){return cleanName(l.replace(/^\s*[⁠‏]*\d+\s*[.)\-]?\s*/,''));}).filter(Boolean);
}
function addPeople(pl,names,group){
  var added=0,skipped=[];
  names.forEach(function(n){
    if(pl.people.some(function(p){return cleanName(p.name)===n;})){skipped.push(n);return;}
    state.pcount=(state.pcount||0)+1;
    pl.people.push({id:'p'+state.pcount+'x'+Math.random().toString(36).slice(2,5),name:n,status:'',note:'',group:group||'',until:'',since:''});added++;
  });
  return {added:added,skipped:skipped};
}
function findPerson(pid){for(var i=0;i<state.platoons.length;i++){var p=find(state.platoons[i].people,pid);if(p)return {pl:state.platoons[i],p:p};}return null;}

/* ---------- views ---------- */
function sec(t,n){return '<h3 class="sec"><span>'+t+'</span>'+(n!=null?'<span class="n">'+n+'</span>':'')+'</h3>';}
function weekStrip(showProgress){
  var ws=weekStart(ui.date),t=todayStr(),h='<div class="week"><button class="wk" data-a="week" data-n="-7" aria-label="שבוע קודם">›</button>';
  for(var i=0;i<7;i++){
    var ds=addDays(ws,i),c=showProgress?dayCount(ds):[0,0],p=c[1]?Math.round(c[0]/c[1]*100):0;
    h+='<button class="day'+(ds===ui.date?' sel':'')+(ds===t?' today':'')+'" data-a="date" data-d="'+ds+'" aria-pressed="'+(ds===ui.date)+'" aria-label="'+dayName(ds)+' '+dm(ds)+'"><span class="dl">'+DL[i]+'</span><span class="dn">'+pd(ds).getDate()+'</span>'+(showProgress?'<span class="pr"><i style="width:'+p+'%"></i></span>':'')+'</button>';
  }
  return h+'<button class="wk" data-a="week" data-n="7" aria-label="שבוע הבא">‹</button></div>';
}
function dateBar(){
  var d=pd(ui.date);
  return '<div class="bar"><label class="datebtn"><span class="d1">'+dayName(ui.date)+'</span><span class="d2">'+d.getDate()+' ב'+MONTHS[d.getMonth()]+' '+d.getFullYear()+(ui.date===todayStr()?' · היום':'')+'</span><input type="date" id="jump" value="'+ui.date+'" aria-label="בחירת תאריך"></label>'+
    (ui.date!==todayStr()?'<button class="pill" data-a="today">חזרה להיום</button>':'')+'</div>';
}
function renderTop(){
  var h='';
  if(ui.tab==='day')h=dateBar()+weekStrip(true);
  else if(ui.tab==='cal'){
    h=dateBar()+'<div style="padding:0 16px 10px"><div class="seg">'+[['month','חודש'],['week','שבוע'],['day','יום']].map(function(x){return '<button data-a="calview" data-v="'+x[0]+'" aria-pressed="'+(S.calView===x[0])+'">'+x[1]+'</button>';}).join('')+'</div></div>';
    if(S.calView==='month'){
      var md=pd(ui.date);
      h+='<div class="mnav"><button class="wk" data-a="month" data-n="-1" aria-label="חודש קודם">›</button><b>'+MONTHS[md.getMonth()]+' '+md.getFullYear()+'</b><button class="wk" data-a="month" data-n="1" aria-label="חודש הבא">‹</button></div>'+
        '<div class="mdow">'+DL.map(function(x){return '<span>'+x+'</span>';}).join('')+'</div>';
    }else h+=weekStrip(false);
  }
  else if(ui.tab==='tasks'){
    h='<div class="bar"><div><h1>משימות</h1><p class="sub">'+state.tasks.length+' משימות · סטטוס בו"ם '+checkCount().join('/')+'</p></div></div>'+
      '<div style="padding:0 16px 10px"><div class="seg">'+[['tasks','כל המשימות'],['status','סטטוס בו"ם'],['rules','כללים']].map(function(x){return '<button data-a="seg" data-v="'+x[0]+'" aria-pressed="'+(ui.seg===x[0])+'">'+x[1]+'</button>';}).join('')+'</div></div>';
  }
  else if(ui.tab==='damach'){
    var tt=totals(),t=todayStr();
    h='<div class="bar"><div><h1>דמ״ח</h1><p class="sub">'+(dow(t)===6?'שבת':'יום '+DX[dow(t)])+' '+dm(t)+' · '+state.platoons.length+' מחלקות</p></div><div class="bigcount">'+tt[0]+'<small>/'+tt[1]+'</small></div></div>';
  }
  else h='<div class="bar"><h1>הגדרות</h1></div>';
  $('#top').innerHTML=h;
}
function taskCard(t,ds,carry){
  var key=t.id+'@'+ds,done=isDone(ds,t.id),open=ui.open===key,chips=[];
  if(t.time)chips.push('<span class="chip red">'+esc(timeLabel(t))+'</span>');
  if(carry)chips.push('<span class="chip fill">מ'+dayName(ds)+'</span>');
  if(t.rep!=='none'&&t.days.length===7)chips.push('<span class="chip">יומי</span>');
  if(t.rep==='none')chips.push('<span class="chip">חד-פעמי</span>');
  if(t.foot&&t.foot.length)chips.push('<span class="chip">'+(t.foot.length===1?'הערה אחת':t.foot.length+' הערות')+'</span>');
  var h='<article class="task'+(done?' done':'')+(open?' open':'')+'">'+
    '<button class="check" data-a="tog" data-ds="'+ds+'" data-id="'+esc(t.id)+'" aria-pressed="'+done+'" aria-label="'+(done?'ביטול סימון':'סימון כבוצע')+': '+esc(t.title)+'">'+I.check+'</button>'+
    '<button class="tmain" data-a="open" data-k="'+esc(key)+'" aria-expanded="'+open+'"><span class="tt">'+esc(t.title)+'</span>'+(t.note?'<span class="tn">'+esc(t.note)+'</span>':'')+(chips.length?'<span class="chips">'+chips.join('')+'</span>':'')+'</button>'+
    '<button class="chev" data-a="open" data-k="'+esc(key)+'" aria-label="פרטים">'+I.chev+'</button>';
  if(open){
    h+='<div class="more">';
    if(t.foot&&t.foot.length)h+='<div><h4>הערות שוליים</h4><ol>'+t.foot.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ol></div>';
    h+='<p class="hint">'+esc(daysLabel(t))+(t.time&&t.remind!==false&&S.notif?' · תזכורת פעילה':'')+'</p>';
    h+='<div class="acts"><button class="btn sm" data-a="edit-task" data-id="'+esc(t.id)+'">'+I.edit+'עריכה</button></div></div>';
  }
  return h+'</article>';
}
function eventRow(e,cals,ds){
  var c=find(cals,e.calId)||{};
  var p=peopleOf(e);
  return '<button class="ev" data-a="event" data-d="'+(ds||ui.date)+'" data-id="'+esc(e.id)+'"><span class="tm">'+(e.allDay?'<span>כל היום</span>':'<span>'+ft(e.begin)+'</span><span>'+ft(e.end)+'</span>')+'</span>'+
    '<span class="body"><span class="tt">'+esc(e.title||'(ללא כותרת)')+'</span>'+(p?'<span class="tn">'+esc(p)+'</span>':'')+(e.loc?'<span class="tn">📍'+esc(e.loc)+'</span>':'')+
    '<span class="cal"><i class="dot" style="background:'+esc(c.color||'#888')+'"></i>'+esc(c.name||'')+'</span></span></button>';
}
function viewDay(){
  var ds=ui.date,t=todayStr(),list=tasksOn(ds),h='';
  var pend=list.filter(function(k){return !isDone(ds,k.id);});
  if(ds===t){
    if(pend.length){var n=pend[0];
      h+='<section class="next"><span class="lbl">הבא בתור'+(n.time?' · '+esc(timeLabel(n)):'')+'</span><span class="big">'+esc(n.title)+'</span>'+(n.note?'<span class="tn">'+esc(n.note)+'</span>':'')+
        '<div class="acts" style="margin-top:6px"><button class="btn primary sm" data-a="tog" data-ds="'+ds+'" data-id="'+esc(n.id)+'">'+I.check+'בוצע</button></div></section>';
    }else if(list.length)h+='<section class="next clear"><span class="lbl">היום סגור</span><span class="big">כל המשימות של היום בוצעו</span></section>';
  }
  if(B.calPerm()){
    var ev=eventsOn(ds);
    if(ev.length){
      h+=sec('בלו"ז',ev.length);
      h+='<button class="row tap" data-a="tab" data-v="cal"><span class="tmain">'+ev.slice(0,4).map(function(e){return '<span class="tn"><b style="color:var(--red);font-variant-numeric:tabular-nums">'+(e.allDay?'כל היום':ft(e.begin))+'</b> '+esc(e.title)+'</span>';}).join('')+(ev.length>4?'<span class="tn">ועוד '+(ev.length-4)+'</span>':'')+'</span><span class="chip">לכל הלו"ז</span></button>';
    }
  }
  h+=sec('משימות',(list.length-pend.length)+'/'+list.length);
  h+=list.length?list.map(function(k){return taskCard(k,ds);}).join(''):'<p class="hint">אין משימות ליום הזה.</p>';
  if(ds===t){var co=carryOver();if(co.length){h+=sec('נשאר פתוח מימים קודמים',co.length);h+=co.map(function(p){return taskCard(p[0],p[1],true);}).join('');}}
  h+=sec('פתקים · '+dayName(ds)+' '+dm(ds));
  h+='<textarea class="note" id="note" data-ds="'+ds+'" placeholder="מה שצריך לזכור היום">'+esc(state.notes[ds]||'')+'</textarea>';
  h+=sec('פתק כללי');
  h+='<textarea class="note" id="gnote" style="min-height:90px" placeholder="דברים שלא קשורים ליום מסוים">'+esc(state.generalNote||'')+'</textarea>';
  return h;
}
function mins(hmStr){var x=hmStr.split(':');return (+x[0])*60+(+x[1]);}
function agenda(ds,evs){
  var cals=calList(),tasks=tasksOn(ds),items=[],h='';
  var dayStart=pd(ds).getTime();
  evs.forEach(function(e,i){items.push([e.allDay?-1:Math.max(0,Math.round((e.begin-dayStart)/60000)),i,eventRow(e,cals,ds)]);});
  var timed=tasks.filter(function(t){return t.time;}),loose=tasks.filter(function(t){return !t.time;});
  timed.forEach(function(t,i){items.push([mins(t.time),100+i,taskCard(t,ds)]);});
  items.sort(function(x,y){return x[0]-y[0]||x[1]-y[1];});
  h+=sec(dayName(ds)+' '+dm(ds)+(ds===todayStr()?' · היום':''),evs.length+' אירועים · '+tasks.length+' משימות');
  if(items.length)h+=items.map(function(x){return x[2];}).join('');
  else h+='<p class="hint">אין אירועים ואין משימות עם שעה ביום הזה.</p>';
  if(loose.length){
    var dn=loose.filter(function(t){return isDone(ds,t.id);}).length;
    h+=sec('משימות בלי שעה',dn+'/'+loose.length);
    h+=loose.map(function(t){return taskCard(t,ds);}).join('');
  }
  h+='<button class="btn ghost wide" data-a="add-task">'+I.plus+'משימה ל'+dayName(ds)+'</button>';
  return h;
}
function monthGrid(map,start,weeks){
  var cur=pd(ui.date).getMonth(),t=todayStr(),h='<div class="mgrid">';
  for(var i=0;i<weeks*7;i++){
    var ds=addDays(start,i),d=pd(ds),ne=(map[ds]||[]).length,tl=tasksOn(ds),open=tl.filter(function(k){return !isDone(ds,k.id);}).length;
    h+='<button class="mc'+(d.getMonth()!==cur?' other':'')+(ds===t?' today':'')+(ds===ui.date?' sel':'')+'" data-a="date" data-d="'+ds+'" aria-pressed="'+(ds===ui.date)+'" aria-label="'+dayName(ds)+' '+dm(ds)+', '+ne+' אירועים, '+open+' משימות פתוחות"><span class="mn">'+d.getDate()+'</span><span class="mk">'+
      (ne?'<i class="me">'+ne+'</i>':'')+(tl.length?(open?'<i class="mt">'+open+'</i>':'<i class="mt ok">✓</i>'):'')+'</span></button>';
  }
  return h+'</div><p class="legend"><i class="me">2</i> אירועים ביומן <i class="mt">3</i> משימות פתוחות <i class="mt ok">✓</i> הכול בוצע</p>';
}
function weekList(map,ws){
  var cals=calList(),t=todayStr(),h='';
  for(var i=0;i<7;i++){
    var ds=addDays(ws,i),evs=map[ds]||[],tl=tasksOn(ds),c=dayCount(ds);
    h+='<section class="wd'+(ds===t?' today':'')+'"><button class="wdh" data-a="pick-day" data-d="'+ds+'"><b>'+dayName(ds)+' '+dm(ds)+(ds===t?' · היום':'')+'</b><span>'+evs.length+' אירועים · '+c[0]+'/'+c[1]+' משימות</span></button>';
    evs.forEach(function(e){var cc=find(cals,e.calId)||{};
      h+='<button class="ln" data-a="event" data-d="'+ds+'" data-id="'+esc(e.id)+'"><i class="dot" style="background:'+esc(cc.color||'#888')+'"></i><b>'+(e.allDay?'כל היום':ft(e.begin)+'–'+ft(e.end))+'</b><span>'+esc(e.title||'(ללא כותרת)')+(e.loc?' · 📍'+esc(e.loc):'')+'</span></button>';});
    tl.forEach(function(k){var dn=isDone(ds,k.id);
      h+='<button class="ln tk'+(dn?' done':'')+'" data-a="tog" data-ds="'+ds+'" data-id="'+esc(k.id)+'" aria-pressed="'+dn+'"><i class="mini">'+I.check+'</i>'+(k.time?'<b>'+esc(timeLabel(k))+'</b>':'')+'<span>'+esc(k.title)+'</span></button>';});
    if(!evs.length&&!tl.length)h+='<p class="hint" style="padding:0 12px 10px">אין כלום ביום הזה.</p>';
    h+='</section>';
  }
  return h;
}
function viewCal(){
  var ds=ui.date,h='';
  if(!NATIVE)h+='<div class="banner"><span><b>תצוגה מקדימה.</b> האירועים כאן הם דוגמה. באפליקציה מופיעים היומנים של Google שמסונכרנים לטלפון, כולל יומנים ששיתפו איתך.</span></div>';
  if(!B.calPerm())h+='<div class="card" style="display:grid;gap:10px"><p class="tt">חיבור ליומן</p><p class="hint">האפליקציה קוראת וכותבת ליומנים שמסונכרנים בטלפון: היומן שלך ב-Google וכל יומן ששיתפו איתך. צריך לאשר גישה ליומן פעם אחת. עד אז מוצגות כאן רק המשימות.</p><div class="acts"><button class="btn primary" data-a="cal-connect">אישור גישה ליומן</button><button class="btn" data-a="cals">בדיקת חיבור</button></div></div>';
  else{
    h+='<div class="acts"><button class="btn primary" data-a="export-luz" style="flex:1">'+I.send+'ייצוא '+dm(ds)+' לוואטסאפ</button><button class="btn" data-a="cals">יומנים</button></div>';
    var ce=B.calError();
    if(!calList().length)h+='<div class="banner"><span><b>הטלפון לא מחזיק אף יומן.</b> לוחצים על "יומנים" כדי לראות מה חסר.</span></div>';
    else if(ce)h+='<div class="banner"><span><b>היומן החזיר שגיאה.</b> לוחצים על "יומנים" כדי לראות אותה.</span></div>';
  }
  if(S.calView==='month'){
    var d=pd(ds),first=new Date(d.getFullYear(),d.getMonth(),1),dim=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();
    var start=addDays(ymd(first),-first.getDay()),weeks=Math.ceil((first.getDay()+dim)/7);
    var map=eventsByDay(start,addDays(start,weeks*7));
    h+=monthGrid(map,start,weeks)+agenda(ds,map[ds]||[]);
  }else if(S.calView==='week'){
    var ws=weekStart(ds);
    h+=weekList(eventsByDay(ws,addDays(ws,7)),ws);
  }else h+=agenda(ds,eventsOn(ds));
  return h;
}
function taskRow(t){
  var chips=['<span class="chip">'+esc(daysLabel(t))+'</span>'];
  if(t.time)chips.push('<span class="chip red">'+esc(timeLabel(t))+'</span>');
  if(t.until)chips.push('<span class="chip">עד '+dm(t.until)+'</span>');
  return '<button class="row tap" data-a="edit-task" data-id="'+esc(t.id)+'"><span class="tmain"><span class="tt">'+esc(t.title)+'</span>'+(t.note?'<span class="tn">'+esc(t.note)+'</span>':'')+'<span class="chips">'+chips.join('')+'</span></span><span class="ibtn">'+I.edit+'</span></button>';
}
function viewTasks(){
  var h='',t=todayStr();
  if(ui.seg==='tasks'){
    var daily=state.tasks.filter(function(k){return k.rep!=='none'&&k.days.length===7;});
    var multi=state.tasks.filter(function(k){return k.rep!=='none'&&k.days.length>1&&k.days.length<7;});
    var once=state.tasks.filter(function(k){return k.rep==='none';}).sort(function(a,b){return a.date<b.date?-1:1;});
    if(daily.length){h+=sec('כל יום',daily.length);h+=daily.map(taskRow).join('');}
    if(multi.length){h+=sec('כמה ימים בשבוע',multi.length);h+=multi.map(taskRow).join('');}
    ALL.forEach(function(d){var l=state.tasks.filter(function(k){return k.rep!=='none'&&k.days.length===1&&k.days[0]===d;});if(l.length){h+=sec((d===6?'שבת':'יום '+DAYS[d]),l.length);h+=l.map(taskRow).join('');}});
    var up=once.filter(function(k){return k.date>=t||!isDone(k.date,k.id);});
    if(up.length){h+=sec('חד-פעמיות',up.length);h+=up.map(taskRow).join('');}
    h+='<button class="btn ghost wide" data-a="add-task">'+I.plus+'משימה חדשה</button>';
  }else if(ui.seg==='status'){
    var cc=checkCount();
    h+='<p class="hint">רשימת המשימות השבועיות לישיבת הסטטוס. הסימונים מתאפסים בתחילת כל שבוע.</p>';
    h+=sec('משימות שבועיות',cc[0]+'/'+cc[1]);
    h+=state.checklist.map(function(c){var dn=cDone(c.id);
      return '<article class="task'+(dn?' done':'')+'"><button class="check" data-a="ctog" data-id="'+esc(c.id)+'" aria-pressed="'+dn+'" aria-label="'+esc(c.title)+'">'+I.check+'</button><div class="tmain"><span class="tt">'+esc(c.title)+'</span>'+(c.note?'<span class="tn">'+esc(c.note)+'</span>':'')+'</div><button class="ibtn" data-a="edit-check" data-id="'+esc(c.id)+'" aria-label="עריכה">'+I.edit+'</button></article>';
    }).join('');
    h+='<button class="btn ghost wide" data-a="add-check">'+I.plus+'פריט חדש לרשימה</button>';
  }else{
    h+='<p class="hint">דברים שאין להם יום קבוע: מה לעשות כשמשהו קורה.</p>';
    h+=state.standing.map(function(s){return '<button class="row tap" data-a="edit-standing" data-id="'+esc(s.id)+'" style="border-inline-start:5px solid var(--red)"><span class="tmain"><span class="tt">'+esc(s.title)+'</span>'+(s.note?'<span class="tn">'+esc(s.note)+'</span>':'')+'</span><span class="ibtn">'+I.edit+'</span></button>';}).join('');
    h+='<button class="btn ghost wide" data-a="add-standing">'+I.plus+'כלל חדש</button>';
  }
  return h;
}
function personBtn(p){return '<button class="nmb" data-a="person" data-id="'+esc(p.id)+'">'+esc(p.name)+(p.note?'<small>'+esc(p.note)+'</small>':'')+'</button>';}
function absRow(p,plName){
  var bits=[];if(plName)bits.push(plName);if(p.note)bits.push(p.note);if(p.since)bits.push('מאז '+dm(p.since));if(p.until)bits.push('עד '+dm(p.until));
  return '<button class="abs" data-a="person" data-id="'+esc(p.id)+'"><span>'+esc(p.name)+(bits.length?'<small>'+esc(bits.join(' · '))+'</small>':'')+'</span><span class="chip fill">'+esc(p.status)+'</span></button>';
}
function platoonCard(pl){
  var c=plCount(pl),open=!!ui.plOpen[pl.id],t=todayStr(),ok=pl.checked===t;
  var h='<section class="pl" id="pl-'+esc(pl.id)+'"><button class="pl-h" data-a="pl-open" data-id="'+esc(pl.id)+'" aria-expanded="'+open+'"><span><span class="nm">'+esc(pl.name)+'</span>'+(pl.commander?'<br><span class="cm">'+esc(pl.commander)+'</span>':'')+'</span>'+
    '<span class="chip'+(ok?'':' red')+'">'+(ok?'נבדק היום':'לא נבדק')+'</span><span class="ct">'+c[0]+'/'+c[1]+'</span></button>';
  if(!open)return h+'</section>';
  h+='<div class="pl-b">';
  var base=pl.people.filter(function(p){return !p.status;});
  function grid(label,list){if(!list.length)return '';return '<p class="grp">'+esc(label)+' · '+list.length+'</p><div class="names">'+list.map(personBtn).join('')+'</div>';}
  if(pl.groups&&pl.groups.length){
    pl.groups.forEach(function(g){h+=grid(g,base.filter(function(p){return p.group===g;}));});
    h+=grid('בבסיס',base.filter(function(p){return pl.groups.indexOf(p.group)<0;}));
  }else h+=grid('בבסיס',base);
  state.statuses.filter(function(s){return s.present;}).forEach(function(s){h+=grid(s.name,pl.people.filter(function(p){return p.status===s.name;}));});
  var abs=pl.people.filter(function(p){return !isPresent(p);});
  if(abs.length){h+='<p class="grp">לא בבסיס · '+abs.length+'</p>'+abs.map(function(p){return absRow(p);}).join('');}
  if(!pl.people.length)h+='<p class="hint">עדיין אין שמות במחלקה.</p>';
  h+='<div class="addrow"><input type="text" id="add-'+esc(pl.id)+'" placeholder="שם חדש" autocomplete="off" enterkeyhint="done" data-enter="pl-add" data-id="'+esc(pl.id)+'"><button class="btn sm" data-a="pl-add" data-id="'+esc(pl.id)+'">הוספה</button></div>';
  h+='<div class="acts"><button class="btn sm '+(ok?'':'primary')+'" data-a="pl-check" data-id="'+esc(pl.id)+'">'+I.check+(ok?'נבדק היום':'עברתי על כולם')+'</button><button class="btn sm" data-a="pl-bulk" data-id="'+esc(pl.id)+'">הדבקת רשימה</button><button class="btn sm" data-a="pl-edit" data-id="'+esc(pl.id)+'">'+I.edit+'מחלקה</button></div>';
  return h+'</div></section>';
}
function searchResults(){
  var q=cleanName(ui.q);if(!q)return '';
  var res=[];state.platoons.forEach(function(pl){pl.people.forEach(function(p){if(p.name.indexOf(q)>=0)res.push([p,pl]);});});
  if(!res.length)return '<p class="hint">לא נמצא אף אחד בשם הזה.</p>';
  return res.slice(0,30).map(function(r){var p=r[0],pl=r[1];
    return isPresent(p)&&!p.status?'<button class="abs" style="border-color:var(--line);background:var(--surface)" data-a="person" data-id="'+esc(p.id)+'"><span>'+esc(p.name)+'<small>'+esc(pl.short||pl.name)+'</small></span><span class="chip">בבסיס</span></button>':absRow(p,pl.short||pl.name);
  }).join('');
}
function viewDamach(){
  var w=damachWarnings(),h='';
  var items=[];
  if(w.unchecked.length)items.push('לא עברת היום על: '+w.unchecked.map(esc).join(', '));
  w.overdue.forEach(function(x){items.push('היה אמור לחזור: '+esc(x));});
  w.dups.forEach(function(x){items.push('מופיע בשתי מחלקות: '+esc(x));});
  if(items.length)h+='<div class="banner"><b>לבדוק לפני שליחה</b><ul>'+items.map(function(x){return '<li>'+x+'</li>';}).join('')+'</ul></div>';
  h+='<input class="search" id="q" type="text" placeholder="חיפוש שם בכל המחלקות" value="'+esc(ui.q)+'" autocomplete="off">';
  h+='<div id="qres" style="display:grid;gap:6px">'+searchResults()+'</div>';
  h+=state.platoons.map(platoonCard).join('');
  h+='<div class="acts"><button class="btn ghost" data-a="add-platoon" style="flex:1">'+I.plus+'מחלקה חדשה</button><button class="btn ghost" data-a="statuses" style="flex:1">סיבות היעדרות</button></div>';
  h+='<div class="sticky-x"><button class="btn primary wide" data-a="export-damach">'+I.send+'ייצוא דמ״ח לוואטסאפ</button></div>';
  return h;
}
function sw(action,on,label,small){return '<div class="switch"><span>'+label+(small?'<small>'+small+'</small>':'')+'</span><button class="sw" data-a="'+action+'" aria-pressed="'+!!on+'" aria-label="'+esc(label)+'"></button></div>';}
function viewSettings(){
  var h='';
  var ok=B.notifOk();
  h+='<section class="set"><h3>התראות</h3>';
  if(NATIVE&&!ok)h+='<div class="banner"><span><b>ההתראות חסומות בטלפון.</b> בלי אישור לא יגיעו תזכורות.</span><button class="btn primary sm" data-a="notif-allow">אישור התראות</button></div>';
  if(NATIVE&&ok&&!B.exactOk())h+='<div class="banner"><span>הטלפון לא מאפשר התראות מדויקות, אז תזכורת יכולה לאחר בכמה דקות.</span></div>';
  h+=sw('set-notif',S.notif,'תזכורות למשימות','משימה עם שעה מקבלת התראה משלה');
  h+='<div class="two"><div class="field"><label for="s-morning">סיכום בוקר</label><input type="time" id="s-morning" data-s="morning" value="'+esc(S.morning)+'"></div><div class="field"><label for="s-evening">מה נשאר פתוח</label><input type="time" id="s-evening" data-s="evening" value="'+esc(S.evening)+'"></div></div>';
  h+='<div class="field"><label for="s-before">כמה זמן לפני המשימה</label><select id="s-before" data-s="before">'+[[0,'בדיוק בזמן'],[5,'5 דקות לפני'],[10,'10 דקות לפני'],[15,'15 דקות לפני'],[30,'חצי שעה לפני'],[60,'שעה לפני']].map(function(x){return '<option value="'+x[0]+'"'+(+S.before===x[0]?' selected':'')+'>'+x[1]+'</option>';}).join('')+'</select></div>';
  h+='<button class="btn" data-a="notif-test">שליחת התראת בדיקה</button>';
  h+='<p class="hint">כדי שהתזכורות יגיעו גם כשהטלפון נח, כדאי לכבות לאפליקציה חיסכון בסוללה בהגדרות הטלפון.</p></section>';

  h+='<section class="set"><h3>ייצוא לוואטסאפ</h3>';
  h+='<div class="field"><label for="s-luz">כותרת הלו"ז</label><input type="text" id="s-luz" data-s="luzTitle" value="'+esc(S.luzTitle)+'"></div>';
  h+='<div class="field"><label for="s-dm">שם הפלוגה בכותרת הדמ"ח</label><input type="text" id="s-dm" data-s="damachTitle" value="'+esc(S.damachTitle)+'"></div>';
  h+=sw('set-pad',S.padHours,'שעות עם אפס מוביל','01:10 במקום 1:10');
  h+=sw('set-empty',S.showEmptyReasons,'להציג בדמ"ח גם סיבות ריקות','כמו בתבנית המקורית');
  h+='</section>';

  h+='<section class="set"><h3>יומנים</h3><p class="hint">אילו יומנים מוצגים ואילו נכנסים לייצוא הלו"ז.</p><button class="btn" data-a="cals">בחירת יומנים</button></section>';
  h+='<section class="set"><h3>מראה</h3>'+sw('set-theme',S.theme==='light','רקע לבן','שחור הוא ברירת המחדל')+'</section>';
  h+='<section class="set"><h3>גיבוי</h3><p class="hint">כל המידע נשמר רק בטלפון הזה. גיבוי שומר את המשימות, הפתקים והדמ"ח כטקסט שאפשר לשחזר ממנו.</p><div class="acts"><button class="btn" data-a="backup">יצירת גיבוי</button><button class="btn" data-a="restore">שחזור מגיבוי</button></div></section>';
  h+='<p class="hint" style="text-align:center">משהד · גרסה 1.1</p>';
  return h;
}
function render(){
  renderTop();
  var m=ui.tab==='day'?viewDay():ui.tab==='cal'?viewCal():ui.tab==='tasks'?viewTasks():ui.tab==='damach'?viewDamach():viewSettings();
  $('#main').innerHTML=m;
  var fab=$('#fab');
  if(ui.tab==='day'){fab.hidden=false;fab.setAttribute('data-a','add-task');fab.innerHTML=I.plus+'משימה';}
  else if(ui.tab==='cal'&&B.calPerm()&&calList().some(function(c){return c.canWrite;})){fab.hidden=false;fab.setAttribute('data-a','add-event');fab.innerHTML=I.plus+'אירוע';}
  else fab.hidden=true;
  var w=damachWarnings(),badge=w.unchecked.length+w.overdue.length;
  var open=tasksOn(todayStr()).filter(function(t){return !isDone(todayStr(),t.id);}).length;
  $('#nav').innerHTML=[['day','היום',I.sun,open],['cal','לו"ז',I.cal,0],['tasks','משימות',I.list,0],['damach','דמ״ח',I.people,badge],['settings','הגדרות',I.gear,0]].map(function(x){
    return '<button data-a="tab" data-v="'+x[0]+'" aria-selected="'+(ui.tab===x[0])+'">'+x[2]+'<span>'+x[1]+'</span>'+(x[3]?'<i class="badge">'+x[3]+'</i>':'')+'</button>';
  }).join('');
  document.documentElement.setAttribute('data-theme',S.theme==='light'?'light':'dark');
}

/* ---------- sheets ---------- */
var sheet=null;
function dayTogs(days){return ALL.map(function(d){return '<button type="button" class="tg" data-a="t-day" data-d="'+d+'" aria-pressed="'+(days.indexOf(d)>=0)+'" aria-label="'+(d===6?'שבת':'יום '+DAYS[d])+'">'+DL[d]+'</button>';}).join('');}
function v(id){var e=document.getElementById(id);return e?e.value.trim():'';}
function delBtn(){return '<button class="btn line" data-a="sh-delete">'+(sheet.confirm?'בטוח? למחוק':'מחיקה')+'</button>';}
function acts(canDelete,saveLabel){return '<p class="err" id="f-err" role="alert">'+esc(sheet.err||'')+'</p><div class="sh-acts"><div class="g"><button class="btn primary" data-a="sh-save">'+(saveLabel||'שמירה')+'</button><button class="btn" data-a="sh-close">ביטול</button></div>'+(canDelete?delBtn():'')+'</div>';}
var SHEETS={
  task:{
    html:function(s){var t=s.d,h='<h2>'+(s.isNew?'משימה חדשה':'עריכת משימה')+'</h2>';
      h+='<div class="field"><label for="f-title">מה צריך לעשות</label><input type="text" id="f-title" value="'+esc(t.title)+'" autocomplete="off"></div>';
      h+='<div class="field"><span class="lbl">מתי</span><div class="seg"><button type="button" data-a="t-rep" data-v="days" aria-pressed="'+(t.rep!=='none')+'">חוזרת</button><button type="button" data-a="t-rep" data-v="none" aria-pressed="'+(t.rep==='none')+'">חד-פעמית</button></div></div>';
      if(t.rep==='none')h+='<div class="field"><label for="f-date">תאריך</label><input type="date" id="f-date" value="'+esc(t.date)+'"></div>';
      else{
        h+='<div class="field"><span class="lbl">באילו ימים</span><div class="togs">'+dayTogs(t.days)+'</div><div class="togs"><button type="button" class="tg w" data-a="t-days" data-v="all">כל יום</button><button type="button" class="tg w" data-a="t-days" data-v="week">א׳ עד ה׳</button><button type="button" class="tg w" data-a="t-days" data-v="none">ניקוי</button></div></div>';
        h+='<div class="field"><label for="f-until">עד תאריך (לא חובה)</label><input type="date" id="f-until" value="'+esc(t.until||'')+'"></div>';
      }
      h+='<div class="field"><span class="lbl">שעות (לא חובה)</span><div class="two"><input type="time" id="f-time" value="'+esc(t.time||'')+'" aria-label="שעת התחלה"><input type="time" id="f-end" value="'+esc(t.end||'')+'" aria-label="שעת סיום"></div><div class="togs"><button type="button" class="tg w" data-a="t-notime">בלי שעה</button></div></div>';
      h+=sw('t-remind',t.remind!==false,'תזכורת','עם שעה: התראה לפני המשימה. בלי שעה: בסיכום הבוקר');
      if(t.remind!==false)h+='<div class="field"><label for="f-before">מתי להתריע</label><select id="f-before"><option value="">לפי ההגדרות</option>'+[[0,'בדיוק בזמן'],[5,'5 דקות לפני'],[10,'10 דקות לפני'],[15,'15 דקות לפני'],[30,'חצי שעה לפני'],[60,'שעה לפני'],[120,'שעתיים לפני']].map(function(x){return '<option value="'+x[0]+'"'+(t.before===x[0]?' selected':'')+'>'+x[1]+'</option>';}).join('')+'</select></div>';
      h+='<div class="field"><label for="f-note">הערה קצרה</label><input type="text" id="f-note" value="'+esc(t.note||'')+'" autocomplete="off"></div>';
      h+='<div class="field"><label for="f-foot">הערות שוליים (שורה לכל הערה)</label><textarea id="f-foot">'+esc((t.foot||[]).join('\n'))+'</textarea></div>';
      return h+acts(!s.isNew);
    },
    read:function(s){var t=s.d;t.title=v('f-title');t.note=v('f-note');t.time=v('f-time');t.end=v('f-end');
      if(document.getElementById('f-date'))t.date=v('f-date');
      if(document.getElementById('f-until'))t.until=v('f-until');
      var b=document.getElementById('f-before');if(b)t.before=b.value===''?null:+b.value;
      t.foot=v('f-foot').split('\n').map(function(x){return x.trim();}).filter(Boolean);},
    save:function(s){var t=s.d;
      if(!t.title)return 'צריך לכתוב מה המשימה.';
      if(t.rep==='none'&&!t.date)return 'צריך לבחור תאריך.';
      if(t.rep!=='none'&&!t.days.length)return 'צריך לבחור לפחות יום אחד.';
      if(t.end&&!t.time)return 'יש שעת סיום בלי שעת התחלה.';
      t.days=t.days.slice().sort();
      if(s.isNew)state.tasks.push(t);else{var i=state.tasks.indexOf(find(state.tasks,t.id));state.tasks[i]=t;}
    },
    del:function(s){state.tasks=state.tasks.filter(function(t){return t.id!==s.d.id;});}
  },
  item:{
    html:function(s){var L={check:['פריט בסטטוס בו"ם','שם','פירוט'],standing:['כלל קבוע','מתי','מה לעשות']}[s.kind];
      return '<h2>'+(s.isNew?L[0]+' חדש':'עריכת '+L[0])+'</h2><div class="field"><label for="f-title">'+L[1]+'</label><input type="text" id="f-title" value="'+esc(s.d.title)+'" autocomplete="off"></div><div class="field"><label for="f-note">'+L[2]+'</label><input type="text" id="f-note" value="'+esc(s.d.note)+'" autocomplete="off"></div>'+acts(!s.isNew);},
    read:function(s){s.d.title=v('f-title');s.d.note=v('f-note');},
    save:function(s){if(!s.d.title)return 'צריך לכתוב שם.';var arr=s.kind==='check'?state.checklist:state.standing;if(s.isNew)arr.push(s.d);else{var o=find(arr,s.d.id);o.title=s.d.title;o.note=s.d.note;}},
    del:function(s){var k=s.kind==='check'?'checklist':'standing';state[k]=state[k].filter(function(x){return x.id!==s.d.id;});}
  },
  event:{
    html:function(s){var e=s.d,cals=calList().filter(function(c){return c.canWrite;});
      var h='<h2>'+(s.isNew?'אירוע חדש':'עריכת אירוע')+'</h2>';
      if(s.readonly){
        h+='<div class="card"><p class="tt">'+esc(e.title)+'</p><p class="tn">'+(e.allDay?'כל היום':'<span class="ltr">'+ft(e.begin)+' - '+ft(e.end)+'</span>')+'</p>'+(e.people?'<p class="tn">'+esc(e.people)+'</p>':'')+(e.loc?'<p class="tn">📍'+esc(e.loc)+'</p>':'')+'</div>';
        h+='<p class="hint">'+(!s.canWrite?'אין לך הרשאת עריכה ביומן הזה.':s.canDelOne?'זה אירוע חוזר. אפשר למחוק מכאן את המופע של היום הזה. כדי לשנות את האירוע עצמו עורכים אותו ביומן Google.':'זה אירוע חוזר. כדי לשנות אותו עורכים אותו ביומן Google.')+'</p>';
        return h+'<p class="err" role="alert">'+esc(s.err||'')+'</p><div class="sh-acts"><div class="g">'+(NATIVE?'<button class="btn primary" data-a="ev-open">פתיחה ביומן Google</button>':'')+'<button class="btn" data-a="sh-close">סגירה</button></div>'+(s.canDelOne?'<button class="btn line" data-a="ev-del-one">'+(s.confirm?'בטוח? למחוק':'מחיקת המופע הזה')+'</button>':'')+'</div>';
      }
      h+='<div class="field"><label for="f-title">כותרת</label><input type="text" id="f-title" value="'+esc(e.title)+'" autocomplete="off"></div>';
      h+='<div class="field"><label for="f-date">תאריך</label><input type="date" id="f-date" value="'+esc(e.date)+'"></div>';
      h+=sw('ev-allday',e.allDay,'כל היום');
      if(!e.allDay)h+='<div class="two"><div class="field"><label for="f-time">התחלה</label><input type="time" id="f-time" value="'+esc(e.time)+'"></div><div class="field"><label for="f-end">סיום</label><input type="time" id="f-end" value="'+esc(e.endt)+'"></div></div>';
      h+='<div class="field"><label for="f-people">מי משתתף (יופיע בסוגריים בייצוא)</label><input type="text" id="f-people" value="'+esc(e.people)+'" autocomplete="off" placeholder="למשל: כלל היוצאים"></div>';
      h+='<div class="field"><label for="f-loc">מיקום</label><input type="text" id="f-loc" value="'+esc(e.loc)+'" autocomplete="off"></div>';
      if(s.isNew)h+='<div class="field"><label for="f-cal">יומן</label><select id="f-cal">'+cals.map(function(c){return '<option value="'+esc(c.id)+'"'+(String(e.calId)===String(c.id)?' selected':'')+'>'+esc(c.name)+(c.account?' · '+esc(c.account):'')+'</option>';}).join('')+'</select></div>';
      return h+acts(!s.isNew);
    },
    read:function(s){if(s.readonly)return;var e=s.d;e.title=v('f-title');e.date=v('f-date');e.people=v('f-people');e.loc=v('f-loc');
      if(document.getElementById('f-time')){e.time=v('f-time');e.endt=v('f-end');}
      var c=document.getElementById('f-cal');if(c)e.calId=c.value;},
    save:function(s){var e=s.d;
      if(!e.title)return 'צריך כותרת.';
      if(!e.date)return 'צריך תאריך.';
      if(s.isNew&&!e.calId)return 'אין יומן שאפשר לכתוב אליו.';
      var o={title:e.title,loc:e.loc,desc:e.people,allDay:!!e.allDay,calId:e.calId};
      if(e.allDay){var a=e.date.split('-');o.begin=Date.UTC(+a[0],+a[1]-1,+a[2]);o.end=o.begin+86400000;}
      else{
        if(!e.time||!e.endt)return 'צריך שעת התחלה ושעת סיום.';
        o.begin=timeAt(e.date,e.time);o.end=timeAt(e.date,e.endt);
        if(o.end<=o.begin)o.end=timeAt(addDays(e.date,1),e.endt);
      }
      var r;
      if(s.isNew){r=B.insertEvent(o);S.lastCal=e.calId;}else{o.id=e.id;r=B.updateEvent(o);}
      if(!r||String(r).indexOf('error')===0)return 'היומן לא קיבל את השינוי. '+String(r||'').replace(/^error:?/,'');
      ui.date=e.date;
    },
    del:function(s){B.deleteEvent(s.d.id);}
  },
  exp:{
    html:function(s){var h='<h2>'+(s.kind==='luz'?'ייצוא לו"ז':'ייצוא דמ״ח')+'</h2>';
      if(s.kind==='luz'){
        var cals=calList().filter(function(c){return !S.calHide[c.id];});
        if(cals.length>1)h+='<div class="field"><span class="lbl">אילו יומנים נכנסים</span><div class="togs">'+cals.map(function(c){return '<button type="button" class="tg w" data-a="x-cal" data-id="'+esc(c.id)+'" aria-pressed="'+!S.calNoExport[c.id]+'">'+esc(c.name)+'</button>';}).join('')+'</div></div>';
      }else{
        var w=damachWarnings();
        if(w.unchecked.length||w.overdue.length)h+='<div class="banner"><b>לבדוק לפני שליחה</b><ul>'+(w.unchecked.length?'<li>לא עברת היום על: '+w.unchecked.map(esc).join(', ')+'</li>':'')+w.overdue.map(function(x){return '<li>היה אמור לחזור: '+esc(x)+'</li>';}).join('')+'</ul></div>';
      }
      h+='<div class="field"><label for="f-text">ההודעה (אפשר לתקן לפני השליחה)</label><textarea class="export" id="f-text" dir="rtl">'+esc(s.text)+'</textarea></div>';
      h+='<div class="sh-acts"><div class="g"><button class="btn primary" data-a="x-wa">'+I.send+'שליחה בוואטסאפ</button><button class="btn" data-a="x-copy">העתקה</button></div><button class="btn" data-a="sh-close">סגירה</button></div>';
      return h;},
    read:function(s){s.text=document.getElementById('f-text').value;}
  },
  cals:{
    html:function(){var cals=calList(),h='<h2>יומנים</h2>';
      var ws=weekStart(todayStr()),n=0,raw=B.calPerm()?(B.events(pd(ws).getTime(),pd(addDays(ws,7)).getTime())||[]):[];n=raw.length;
      var err=B.calError(),off=cals.filter(function(c){return c.synced===false;});
      h+='<div class="card" style="display:grid;gap:4px;font-size:14px"><b>מצב החיבור</b>'+
        '<span>הרשאה ליומן: '+(B.calPerm()?'יש':'אין')+'</span>'+
        '<span>יומנים שנמצאו בטלפון: '+cals.length+'</span>'+
        '<span>אירועים השבוע בכל היומנים: '+n+'</span>'+
        (off.length?'<span style="color:var(--red)">לא מסונכרנים לטלפון: '+off.map(function(c){return esc(c.name);}).join(', ')+'</span>':'')+
        (err?'<span style="color:var(--red)" dir="ltr">'+esc(err)+'</span>':'')+'</div>';
      if(!B.calPerm())h+='<button class="btn primary" data-a="cal-connect">אישור גישה ליומן</button>';
      else if(!cals.length)h+='<p class="hint">הטלפון לא מחזיק אף יומן. פותחים את אפליקציית היומן של Google, נכנסים עם החשבון, ומוודאים בהגדרות הטלפון שסנכרון היומן של החשבון פועל.</p>';
      else{h+='<p class="hint">האפליקציה מציגה רק יומנים שהטלפון מסנכרן. אם יומן ששיתפו איתך חסר כאן או מסומן "לא מסונכרן": באפליקציית היומן של Google פותחים הגדרות, בוחרים את היומן תחת החשבון ומפעילים סנכרון. אחרי דקה חוזרים לכאן.</p><div class="listrow" style="font-size:12px;color:var(--muted);font-weight:700"><span>יומן</span><span>מוצג</span><span>בייצוא</span></div>';
        h+=cals.map(function(c){return '<div class="listrow"><span><i class="dot" style="background:'+esc(c.color||'#888')+'"></i> '+esc(c.name)+'<small>'+esc(c.account||'')+(c.canWrite?'':' · קריאה בלבד')+(c.synced===false?' · לא מסונכרן':'')+'</small></span><button class="sw" data-a="c-show" data-id="'+esc(c.id)+'" aria-pressed="'+!S.calHide[c.id]+'" aria-label="להציג את '+esc(c.name)+'"></button><button class="sw" data-a="c-exp" data-id="'+esc(c.id)+'" aria-pressed="'+(!S.calHide[c.id]&&!S.calNoExport[c.id])+'" aria-label="לייצא את '+esc(c.name)+'"></button></div>';}).join('');}
      return h+'<div class="sh-acts"><div class="g"><button class="btn primary" data-a="sh-close">סיום</button><button class="btn" data-a="cals-refresh">רענון</button></div></div>';}
  },
  person:{
    html:function(s){var f=findPerson(s.pid);if(!f)return '';var p=f.p,pl=f.pl;
      var h='<h2>'+esc(p.name)+'</h2><p class="hint">'+esc(pl.name)+' · '+(p.status?esc(p.status)+(p.since?' מאז '+dm(p.since):''):'בבסיס')+'</p>';
      h+='<div class="field"><span class="lbl">איפה עכשיו (לחיצה שומרת וסוגרת)</span><div class="togs"><button type="button" class="tg w" data-a="p-status" data-v="" aria-pressed="'+!p.status+'">בבסיס</button>'+
        state.statuses.map(function(st){return '<button type="button" class="tg w" data-a="p-status" data-v="'+esc(st.name)+'" aria-pressed="'+(p.status===st.name)+'">'+esc(st.name)+'</button>';}).join('')+'</div></div>';
      h+='<div class="two"><div class="field"><label for="f-note">הערה</label><input type="text" id="f-note" value="'+esc(p.note)+'" autocomplete="off" placeholder="למשל: הכנה למכים"></div><div class="field"><label for="f-until">חוזר בתאריך (לא חובה)</label><input type="date" id="f-until" value="'+esc(p.until||'')+'"></div></div>';
      h+='<div class="field"><label for="f-name">שם</label><input type="text" id="f-name" value="'+esc(p.name)+'" autocomplete="off"></div>';
      if(pl.groups&&pl.groups.length)h+='<div class="field"><label for="f-group">קבוצה</label><select id="f-group"><option value="">ללא</option>'+pl.groups.map(function(g){return '<option'+(p.group===g?' selected':'')+'>'+esc(g)+'</option>';}).join('')+'</select></div>';
      if(state.platoons.length>1)h+='<div class="field"><label for="f-pl">מחלקה</label><select id="f-pl">'+state.platoons.map(function(x){return '<option value="'+esc(x.id)+'"'+(x.id===pl.id?' selected':'')+'>'+esc(x.name)+'</option>';}).join('')+'</select></div>';
      return h+acts(true);},
    read:function(s){var f=findPerson(s.pid);if(!f)return;s.note=v('f-note');s.until=v('f-until');s.name=cleanName(v('f-name'));var g=document.getElementById('f-group');s.group=g?g.value:f.p.group;var pl=document.getElementById('f-pl');s.plId=pl?pl.value:f.pl.id;},
    save:function(s){var f=findPerson(s.pid);if(!f)return;if(!s.name)return 'צריך שם.';
      var p=f.p;p.name=s.name;p.note=s.note;p.until=s.until;p.group=s.group;
      if(s.status!==undefined&&s.status!==p.status){p.status=s.status;p.since=s.status?todayStr():'';if(!s.status)p.until='';}
      if(s.plId&&s.plId!==f.pl.id){var to=find(state.platoons,s.plId);f.pl.people=f.pl.people.filter(function(x){return x.id!==p.id;});if(to.groups.indexOf(p.group)<0)p.group='';to.people.push(p);}
    },
    del:function(s){var f=findPerson(s.pid);if(f)f.pl.people=f.pl.people.filter(function(x){return x.id!==s.pid;});}
  },
  platoon:{
    html:function(s){var p=s.d,h='<h2>'+(s.isNew?'מחלקה חדשה':'עריכת מחלקה')+'</h2>';
      h+='<div class="field"><label for="f-name">שם המחלקה</label><input type="text" id="f-name" value="'+esc(p.name)+'" autocomplete="off"></div>';
      h+='<div class="two"><div class="field"><label for="f-short">שם קצר לסיכום</label><input type="text" id="f-short" value="'+esc(p.short)+'" autocomplete="off"></div><div class="field"><label for="f-cmd">מפקד</label><input type="text" id="f-cmd" value="'+esc(p.commander)+'" autocomplete="off"></div></div>';
      h+='<div class="field"><label for="f-base">כותרת לרשימת הנוכחים</label><input type="text" id="f-base" value="'+esc(p.baseLabel)+'" autocomplete="off" placeholder="למשל: בסיס"></div>';
      h+='<div class="field"><label for="f-groups">קבוצות בתוך המחלקה (עם פסיקים, לא חובה)</label><input type="text" id="f-groups" value="'+esc((p.groups||[]).join(', '))+'" autocomplete="off" placeholder="למשל: סגל, חיילים"></div>';
      if(!s.isNew)h+='<div class="acts"><button class="btn sm" data-a="pl-move" data-n="-1">הזזה למעלה</button><button class="btn sm" data-a="pl-move" data-n="1">הזזה למטה</button></div>';
      return h+acts(!s.isNew);},
    read:function(s){var p=s.d;p.name=v('f-name');p.short=v('f-short');p.commander=v('f-cmd');p.baseLabel=v('f-base');p.groups=v('f-groups').split(',').map(function(x){return x.trim();}).filter(Boolean);},
    save:function(s){var p=s.d;if(!p.name)return 'צריך שם למחלקה.';if(!p.short)p.short=p.name;
      if(s.isNew){state.platoons.push(p);ui.plOpen[p.id]=true;}else{var o=find(state.platoons,p.id);o.name=p.name;o.short=p.short;o.commander=p.commander;o.baseLabel=p.baseLabel;o.groups=p.groups;}},
    del:function(s){state.platoons=state.platoons.filter(function(x){return x.id!==s.d.id;});}
  },
  bulk:{
    html:function(s){var pl=find(state.platoons,s.plId);
      return '<h2>הדבקת רשימה · '+esc(pl.name)+'</h2><p class="hint">שם בכל שורה. אפשר להדביק ישר מוואטסאפ, המספור יורד לבד. שמות שכבר קיימים במחלקה לא יתווספו שוב.</p><div class="field"><label for="f-names">שמות</label><textarea id="f-names" style="min-height:200px">'+esc(s.text||'')+'</textarea></div>'+
      (pl.groups&&pl.groups.length?'<div class="field"><label for="f-group">קבוצה</label><select id="f-group"><option value="">ללא</option>'+pl.groups.map(function(g){return '<option>'+esc(g)+'</option>';}).join('')+'</select></div>':'')+acts(false,'הוספה');},
    read:function(s){s.text=document.getElementById('f-names').value;var g=document.getElementById('f-group');s.group=g?g.value:'';},
    save:function(s){var names=parseNames(s.text);if(!names.length)return 'לא מצאתי שמות ברשימה.';var r=addPeople(find(state.platoons,s.plId),names,s.group);
      toast('נוספו '+r.added+(r.skipped.length?' · '+r.skipped.length+' כבר היו ברשימה':''));}
  },
  statuses:{
    html:function(s){var h='<h2>סיבות היעדרות</h2><p class="hint">"נחשב נוכח" מתאים למי שלא בבסיס אבל נספר, כמו תורנות חוץ.</p><div class="listrow" style="font-size:12px;color:var(--muted);font-weight:700"><span>סיבה</span><span>נחשב נוכח</span><span></span></div>';
      h+=state.statuses.map(function(st,i){return '<div class="listrow"><span>'+esc(st.name)+'</span><button class="sw" data-a="st-present" data-i="'+i+'" aria-pressed="'+!!st.present+'" aria-label="'+esc(st.name)+' נחשב נוכח"></button><button class="btn sm line" data-a="st-del" data-i="'+i+'">'+(s.confirmI===i?'בטוח?':'מחיקה')+'</button></div>';}).join('');
      h+='<div class="addrow"><input type="text" id="f-st" placeholder="סיבה חדשה" autocomplete="off"><button class="btn sm" data-a="st-add">הוספה</button></div>';
      return h+'<p class="err">'+esc(s.err||'')+'</p><div class="sh-acts"><button class="btn primary" data-a="sh-close">סיום</button></div>';}
  },
  restore:{
    html:function(s){return '<h2>שחזור מגיבוי</h2><p class="hint">להדביק כאן את טקסט הגיבוי. השחזור מחליף את כל מה שיש עכשיו באפליקציה.</p><div class="field"><label for="f-json">טקסט הגיבוי</label><textarea id="f-json" style="min-height:160px" dir="ltr"></textarea></div>'+acts(false,'שחזור');},
    read:function(s){s.text=document.getElementById('f-json').value;},
    save:function(s){var o;try{o=JSON.parse(s.text);}catch(e){return 'הטקסט לא נקרא כגיבוי. צריך להדביק אותו במלואו.';}
      if(!o||!o.tasks||!o.platoons)return 'זה לא גיבוי של האפליקציה.';
      state=normalize(o);S=state.settings;toast('הגיבוי שוחזר');}
  }
};
function openSheet(s){sheet=s;drawSheet();}
function closeSheet(){sheet=null;drawSheet();}
function drawSheet(){
  var el=$('#sheet');
  if(!sheet){el.hidden=true;el.innerHTML='';return;}
  var old=$('.sh',el),st=old?old.scrollTop:0;
  el.hidden=false;el.innerHTML='<div class="sh" role="dialog" aria-modal="true">'+SHEETS[sheet.type].html(sheet)+'</div>';
  $('.sh',el).scrollTop=st;
}
function readSheet(){if(sheet&&SHEETS[sheet.type].read&&$('#sheet .sh'))SHEETS[sheet.type].read(sheet);}
var toastT=null;
function toast(m){var t=$('#toast');t.innerHTML='<span>'+esc(m)+'</span>';t.hidden=false;clearTimeout(toastT);toastT=setTimeout(function(){t.hidden=true;},2200);}

function newTask(){return {id:uid('t'),title:'',rep:ui.tab==='tasks'?'days':'none',days:[dow(ui.date)],date:ui.date,until:'',time:'',end:'',remind:true,before:null,note:'',foot:[]};}
function editEvent(e){
  var cals=calList(),c=find(cals,e.calId)||{};
  var d={id:e.id,calId:e.calId,title:e.title||'',loc:e.loc||'',people:peopleOf(e),allDay:!!e.allDay,begin:e.begin,end:e.end,
    date:e.allDay?new Date(e.begin).toISOString().slice(0,10):ymd(new Date(e.begin)),time:hm(e.begin),endt:hm(e.end)};
  openSheet({type:'event',d:d,isNew:false,readonly:!c.canWrite||!!e.recurring||!!e.exception,canWrite:!!c.canWrite,canDelOne:!!c.canWrite&&!!e.recurring&&!e.exception,raw:e});
}

/* ---------- events ---------- */
function act(a,b){
  var id=b.getAttribute('data-id'),val=b.getAttribute('data-v');
  switch(a){
    case 'tab':ui.tab=val;window.scrollTo(0,0);render();break;
    case 'date':ui.date=b.getAttribute('data-d');render();break;
    case 'week':ui.date=addDays(ui.date,+b.getAttribute('data-n'));render();break;
    case 'today':ui.date=todayStr();render();break;
    case 'seg':ui.seg=val;render();break;
    case 'tog':toggleDone(b.getAttribute('data-ds'),id);render();break;
    case 'open':var k=b.getAttribute('data-k');ui.open=ui.open===k?null:k;render();break;
    case 'ctog':cToggle(id);render();break;
    case 'add-task':openSheet({type:'task',d:newTask(),isNew:true});break;
    case 'edit-task':openSheet({type:'task',d:clone(find(state.tasks,id)),isNew:false});break;
    case 'add-check':openSheet({type:'item',kind:'check',d:{id:uid('c'),title:'',note:''},isNew:true});break;
    case 'edit-check':openSheet({type:'item',kind:'check',d:clone(find(state.checklist,id)),isNew:false});break;
    case 'add-standing':openSheet({type:'item',kind:'standing',d:{id:uid('s'),title:'',note:''},isNew:true});break;
    case 'edit-standing':openSheet({type:'item',kind:'standing',d:clone(find(state.standing,id)),isNew:false});break;
    case 'cal-connect':B.reqCal();if(sheet)closeSheet();break;
    case 'cals':openSheet({type:'cals'});break;
    case 'cals-refresh':drawSheet();render();break;
    case 'add-event':
      var cw=calList().filter(function(c){return c.canWrite;});
      if(!cw.length){toast('אין יומן שאפשר לכתוב אליו');break;}
      var now=new Date(),h0=pad(Math.min(now.getHours()+1,23))+':00',h1=pad(Math.min(now.getHours()+2,23))+':'+(now.getHours()>=22?'59':'00');
      openSheet({type:'event',isNew:true,d:{calId:find(cw,S.lastCal)?S.lastCal:cw[0].id,title:'',loc:'',people:'',allDay:false,date:ui.date,time:h0,endt:h1}});break;
    case 'event':var eds=b.getAttribute('data-d')||ui.date,ev=eventsOn(eds).filter(function(e){return String(e.id)===id;})[0];if(ev){ui.date=eds;editEvent(ev);}break;
    case 'ev-del-one':
      if(!sheet.confirm){sheet.confirm=true;drawSheet();break;}
      var dr=B.deleteInstance(sheet.raw);
      if(!dr||String(dr).indexOf('error')===0){sheet.err='היומן לא קיבל את המחיקה. אפשר למחוק דרך יומן Google.';sheet.confirm=false;drawSheet();break;}
      closeSheet();render();toast('המופע נמחק');break;
    case 'calview':S.calView=val;save();render();break;
    case 'pick-day':ui.date=b.getAttribute('data-d');S.calView='day';save();window.scrollTo(0,0);render();break;
    case 'month':var md=pd(ui.date),tm=new Date(md.getFullYear(),md.getMonth()+(+b.getAttribute('data-n')),1),last=new Date(tm.getFullYear(),tm.getMonth()+1,0).getDate();tm.setDate(Math.min(md.getDate(),last));ui.date=ymd(tm);render();break;
    case 'ev-open':B.openEvent(sheet.raw);break;
    case 'ev-allday':sheet.d.allDay=!sheet.d.allDay;drawSheet();break;
    case 'export-luz':openSheet({type:'exp',kind:'luz',ds:ui.date,text:luzText(ui.date)});break;
    case 'export-damach':openSheet({type:'exp',kind:'damach',text:damachText(todayStr())});break;
    case 'x-cal':if(S.calNoExport[id])delete S.calNoExport[id];else S.calNoExport[id]=1;save();sheet.text=luzText(sheet.ds);drawSheet();break;
    case 'x-wa':B.share(sheet.text,true);if(!NATIVE)toast('ההודעה הועתקה. באפליקציה היא נפתחת ישר בוואטסאפ');break;
    case 'x-copy':B.copy(sheet.text);toast('הועתק');break;
    case 'c-show':if(S.calHide[id])delete S.calHide[id];else S.calHide[id]=1;save();drawSheet();render();break;
    case 'c-exp':if(S.calNoExport[id])delete S.calNoExport[id];else S.calNoExport[id]=1;save();drawSheet();break;
    case 't-rep':sheet.d.rep=val;if(val==='none'&&!sheet.d.date)sheet.d.date=ui.date;drawSheet();break;
    case 't-day':var d=+b.getAttribute('data-d'),ix=sheet.d.days.indexOf(d);if(ix>=0)sheet.d.days.splice(ix,1);else sheet.d.days.push(d);drawSheet();break;
    case 't-days':sheet.d.days=val==='all'?ALL.slice():val==='week'?[0,1,2,3,4]:[];drawSheet();break;
    case 't-notime':sheet.d.time='';sheet.d.end='';drawSheet();break;
    case 't-remind':sheet.d.remind=sheet.d.remind===false;drawSheet();break;
    case 'pl-open':ui.plOpen[id]=!ui.plOpen[id];render();break;
    case 'pl-check':var pl=find(state.platoons,id);pl.checked=pl.checked===todayStr()?'':todayStr();save();render();break;
    case 'pl-add':
      var inp=document.getElementById('add-'+id),names=parseNames(inp?inp.value:'');
      if(!names.length){if(inp)inp.focus();break;}
      var r=addPeople(find(state.platoons,id),names);save();render();
      toast(r.added?'נוסף: '+names.join(', '):'כבר קיים במחלקה');
      var again=document.getElementById('add-'+id);if(again)again.focus();break;
    case 'pl-bulk':openSheet({type:'bulk',plId:id,text:''});break;
    case 'pl-edit':openSheet({type:'platoon',d:clone(find(state.platoons,id)),isNew:false});break;
    case 'add-platoon':openSheet({type:'platoon',isNew:true,d:{id:uid('pl'),name:'',short:'',commander:'',baseLabel:'נוכחים',groups:[],checked:'',people:[]}});break;
    case 'pl-move':var i=state.platoons.indexOf(find(state.platoons,sheet.d.id)),j=i+(+b.getAttribute('data-n'));if(j>=0&&j<state.platoons.length){var x=state.platoons.splice(i,1)[0];state.platoons.splice(j,0,x);save();render();toast('הוזז');}break;
    case 'person':openSheet({type:'person',pid:id});break;
    case 'p-status':sheet.status=val;var e1=SHEETS.person.save(sheet);if(e1){sheet.err=e1;drawSheet();break;}save();closeSheet();render();break;
    case 'statuses':openSheet({type:'statuses'});break;
    case 'st-present':var st=state.statuses[+b.getAttribute('data-i')];st.present=!st.present;save();drawSheet();render();break;
    case 'st-del':var si=+b.getAttribute('data-i');
      if(sheet.confirmI!==si){sheet.confirmI=si;drawSheet();break;}
      var nm=state.statuses[si].name,used=0;state.platoons.forEach(function(p){p.people.forEach(function(q){if(q.status===nm)used++;});});
      if(used){sheet.err=used+' אנשים מסומנים עכשיו כ"'+nm+'". צריך לשנות להם קודם.';sheet.confirmI=null;drawSheet();break;}
      state.statuses.splice(si,1);sheet.confirmI=null;sheet.err='';save();drawSheet();break;
    case 'st-add':var n2=cleanName(v('f-st'));if(!n2)break;if(stOf(n2)){sheet.err='הסיבה הזאת כבר קיימת.';drawSheet();break;}state.statuses.push({name:n2,present:false});sheet.err='';save();drawSheet();break;
    case 'set-notif':S.notif=!S.notif;save();if(S.notif&&NATIVE&&!B.notifOk())B.reqNotif();render();break;
    case 'set-pad':S.padHours=!S.padHours;save();render();break;
    case 'set-empty':S.showEmptyReasons=!S.showEmptyReasons;save();render();break;
    case 'set-theme':S.theme=S.theme==='light'?'dark':'light';save();render();break;
    case 'notif-allow':B.reqNotif();break;
    case 'notif-test':B.testNotif();if(NATIVE)toast('התראת בדיקה תגיע בעוד 10 שניות');break;
    case 'backup':B.share(JSON.stringify(state),false);if(!NATIVE)toast('הגיבוי הועתק');break;
    case 'restore':openSheet({type:'restore'});break;
    case 'sh-close':closeSheet();break;
    case 'sh-save':
      var err=SHEETS[sheet.type].save(sheet);
      if(err){sheet.err=err;drawSheet();break;}
      save();closeSheet();render();break;
    case 'sh-delete':
      if(!sheet.confirm){sheet.confirm=true;drawSheet();break;}
      SHEETS[sheet.type].del(sheet);save();closeSheet();render();break;
  }
}
document.addEventListener('click',function(e){
  var b=e.target.closest('[data-a]');
  if(!b){if(sheet&&e.target.id==='sheet')closeSheet();return;}
  if(sheet&&b.closest('#sheet'))readSheet();
  act(b.getAttribute('data-a'),b);
});
var noteT=null;
document.addEventListener('input',function(e){
  var t=e.target;
  if(t.id==='note'||t.id==='gnote'){
    if(t.id==='note'){var ds=t.getAttribute('data-ds');if(t.value)state.notes[ds]=t.value;else delete state.notes[ds];}else state.generalNote=t.value;
    clearTimeout(noteT);noteT=setTimeout(save,500);
  }else if(t.id==='q'){ui.q=t.value;$('#qres').innerHTML=searchResults();}
});
document.addEventListener('change',function(e){
  var t=e.target;
  if(t.id==='jump'&&t.value){ui.date=t.value;render();}
  var k=t.getAttribute('data-s');
  if(k){S[k]=k==='before'?+t.value:t.value;save();}
});
document.addEventListener('keydown',function(e){
  if(e.key==='Enter'&&e.target.getAttribute&&e.target.getAttribute('data-enter')){e.preventDefault();act(e.target.getAttribute('data-enter'),e.target);}
  if(e.key==='Escape'&&sheet)closeSheet();
});
function flush(){clearTimeout(noteT);B.save(JSON.stringify(state));}
document.addEventListener('visibilitychange',function(){if(document.hidden)flush();});
window.addEventListener('pagehide',flush);

/* called by the Android side */
window.onBack=function(){if(sheet){closeSheet();return true;}if(ui.tab!=='day'){ui.tab='day';render();return true;}return false;};
window.onResume=function(){var t=todayStr();if(t!==lastToday){if(ui.date===lastToday)ui.date=t;lastToday=t;prune();}if(!sheet)render();pushAlarms();};
window.onPermission=function(kind,granted){render();if(kind==='calendar'&&!granted)toast('בלי אישור אי אפשר להציג את היומן');if(kind==='notifications')pushAlarms();};
setInterval(function(){if(todayStr()!==lastToday&&!sheet)window.onResume();},60000);

/* test hooks for the preview build */
window.__app={eventsByDay:eventsByDay,luzText:luzText,damachText:damachText,totals:totals,buildAlarms:buildAlarms,state:function(){return state;},tasksOn:tasksOn,parseNames:parseNames};

prune();
render();
pushAlarms();
if(NATIVE&&S.notif&&!B.notifOk()&&!state.askedNotif){state.askedNotif=true;B.save(JSON.stringify(state));B.reqNotif();}
})();
