#!/usr/bin/env python3
"""Assemble the single-file web app (fonts inlined) into the Android assets folder."""
import base64, pathlib
root = pathlib.Path(__file__).parent
def b64(p): return base64.b64encode((root/p).read_bytes()).decode()
fonts = """@font-face{font-family:'Heebo';font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:U+0307-0308,U+0590-05FF,U+200C-2010,U+20AA,U+25CC,U+FB1D-FB4F}
@font-face{font-family:'Heebo';font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
""" % (b64('web/fonts/heebo-hebrew-wght-normal.woff2'), b64('web/fonts/heebo-latin-wght-normal.woff2'))
html = """<!DOCTYPE html>
<html lang="he" dir="rtl" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>משהד</title>
<style>
%s%s</style>
</head>
<body>
<header id="top"></header>
<main id="main"></main>
<button id="fab" class="fab" hidden></button>
<nav id="nav" aria-label="ניווט"></nav>
<div id="sheet" hidden></div>
<div id="toast" hidden></div>
<script>
%s
</script>
<script>
%s
</script>
</body>
</html>
""" % (fonts, (root/'web/style.css').read_text(encoding='utf-8'), (root/'web/data.js').read_text(encoding='utf-8'), (root/'web/app.js').read_text(encoding='utf-8'))
out = root/'android/app/src/main/assets/index.html'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html, encoding='utf-8')
print('wrote', out, len(html)//1024, 'KB')
