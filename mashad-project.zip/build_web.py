#!/usr/bin/env python3
"""Assemble the single-file web app (fonts inlined) into the Android assets folder."""
import base64, pathlib
root = pathlib.Path(__file__).parent
def b64(p): return base64.b64encode((root/p).read_bytes()).decode()
fonts = """@font-face{font-family:'Heebo';font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:U+0307-0308,U+0590-05FF,U+200C-2010,U+20AA,U+25CC,U+FB1D-FB4F}
@font-face{font-family:'Heebo';font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
""" % (b64('web/fonts/heebo-hebrew-wght-normal.woff2'), b64('web/fonts/heebo-latin-wght-normal.woff2'))
html = """<!DOCTYPE html>
<html lang="he" dir="rtl" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mash</title>
<style>
%s%s</style>
</head>
<body>
<div id="splash"><svg class="s-logo" viewBox="0 0 108 108" aria-hidden="true"><circle cx="54" cy="54" r="54" fill="#e3120b"/><g transform="translate(17,17) scale(0.72)"><path fill="#000" d="M96 48 L91 41 L82 41 L70 33 L60 29 L50 4 L49 27 L26 8 L37 35 L12 30 L30 45 L7 51 L27 58 L9 71 L30 72 L24 97 L62 97 L57 78 L61 68 L74 71 L92 63 L84 60 L68 59 L77 55 L80 60 L83 54 L87 58 L90 52 Z"/><path fill="#fff" d="M60 39 L73 42 L68 46 L58 43 Z"/></g></svg><div class="s-name" id="splash-name">מבצעית ג׳</div><div class="s-line"></div><div class="s-sub">MASH</div></div>
<header id="top"></header>
<main id="main"></main>
<button id="fab" class="fab" hidden></button>
<nav id="nav" aria-label="ניווט"></nav>
<div id="sheet" hidden></div>
<div id="toast" hidden></div>
<script>
%s
</script>
<script>
%s
</script>
<script>
%s
</script>
</body>
</html>
""" % (fonts, (root/'web/style.css').read_text(encoding='utf-8'), (root/'web/data.js').read_text(encoding='utf-8'), (root/'web/en.js').read_text(encoding='utf-8'), (root/'web/app.js').read_text(encoding='utf-8'))
out = root/'android/app/src/main/assets/index.html'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html, encoding='utf-8')
print('wrote', out, len(html)//1024, 'KB')
