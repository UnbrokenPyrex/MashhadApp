package com.mashad.planner;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.TimeZone;

/**
 * The whole interface is the bundled web page in assets/index.html.
 * This activity hosts it and gives it the phone features it needs through the "Android" bridge:
 * storage, the device calendar (which includes every Google calendar synced to the phone,
 * shared ones too), reminders and sharing to WhatsApp.
 * The app has no internet permission; nothing leaves the phone unless the user shares it.
 */
public class MainActivity extends Activity {
    private static final int REQ_CALENDAR = 1;
    private static final int REQ_NOTIFICATIONS = 2;
    private static final String STATE_FILE = "state.json";

    private WebView web;
    private final Object fileLock = new Object();
    /** Last problem the calendar storage reported, shown on the calendars screen so it can be diagnosed. */
    private volatile String calError = "";

    private static final String[] EVENT_COLUMNS_BASIC = {
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.CALENDAR_ID
    };
    private static final String[] EVENT_COLUMNS_FULL = {
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.CALENDAR_ID,
            CalendarContract.Instances.RRULE,
            CalendarContract.Instances.RDATE,
            CalendarContract.Instances.ORIGINAL_ID,
            CalendarContract.Instances.STATUS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Notifier.ensureChannel(this);

        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("file:///android_asset/")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            js("window.onResume&&window.onResume()");
        }
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(window.onBack&&window.onBack())?'1':'0'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("1")) moveTaskToBack(true);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0;
        for (int r : grantResults) if (r != PackageManager.PERMISSION_GRANTED) granted = false;
        if (requestCode == REQ_CALENDAR) js("window.onPermission&&window.onPermission('calendar'," + granted + ")");
        if (requestCode == REQ_NOTIFICATIONS) js("window.onPermission&&window.onPermission('notifications'," + granted + ")");
    }

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private boolean has(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean calendarAllowed() {
        return has(Manifest.permission.READ_CALENDAR) && has(Manifest.permission.WRITE_CALENDAR);
    }

    private static String str(Cursor c, int i) {
        return c.isNull(i) ? "" : c.getString(i);
    }

    private static String message(Exception e) {
        String m = e.getMessage();
        return "error:" + (m == null ? e.getClass().getSimpleName() : m);
    }

    /** Everything the page can ask the phone to do. Methods run on a background thread. */
    public final class Bridge {

        // ---------- storage ----------

        @JavascriptInterface
        public String loadState() {
            synchronized (fileLock) {
                File f = new File(getFilesDir(), STATE_FILE);
                if (!f.exists()) return "";
                try (FileInputStream in = new FileInputStream(f)) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    return new String(out.toByteArray(), StandardCharsets.UTF_8);
                } catch (Exception e) {
                    return "";
                }
            }
        }

        @JavascriptInterface
        public void saveState(String json) {
            if (json == null || json.length() < 2) return;
            synchronized (fileLock) {
                File tmp = new File(getFilesDir(), STATE_FILE + ".tmp");
                File dst = new File(getFilesDir(), STATE_FILE);
                try {
                    try (FileOutputStream out = new FileOutputStream(tmp)) {
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                        out.getFD().sync();
                    }
                    if (!tmp.renameTo(dst)) {
                        try (FileOutputStream out = new FileOutputStream(dst)) {
                            out.write(json.getBytes(StandardCharsets.UTF_8));
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }

        // ---------- sharing ----------

        @JavascriptInterface
        public void share(final String text, final boolean whatsapp) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    if (whatsapp) {
                        String[] packages = {"com.whatsapp", "com.whatsapp.w4b"};
                        for (String p : packages) {
                            try {
                                send.setPackage(p);
                                startActivity(send);
                                return;
                            } catch (ActivityNotFoundException ignored) {
                            }
                        }
                        send.setPackage(null);
                    }
                    try {
                        startActivity(Intent.createChooser(send, null));
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("mashad", text));
                }
            });
        }

        // ---------- calendar ----------

        @JavascriptInterface
        public boolean hasCalendarPermission() {
            return calendarAllowed();
        }

        @JavascriptInterface
        public void requestCalendarPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    SharedPreferences prefs = getSharedPreferences("mashad", MODE_PRIVATE);
                    boolean askedBefore = prefs.getBoolean("askedCalendar", false);
                    if (askedBefore && !shouldShowRequestPermissionRationale(Manifest.permission.READ_CALENDAR)) {
                        // The system will not show the dialog again; send the user to the app's settings page.
                        try {
                            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                        } catch (Exception ignored) {
                        }
                        return;
                    }
                    prefs.edit().putBoolean("askedCalendar", true).apply();
                    requestPermissions(new String[]{Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR}, REQ_CALENDAR);
                }
            });
        }

        @JavascriptInterface
        public String listCalendars() {
            JSONArray out = new JSONArray();
            if (!calendarAllowed()) return out.toString();
            String[] proj = {
                    CalendarContract.Calendars._ID,
                    CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                    CalendarContract.Calendars.ACCOUNT_NAME,
                    CalendarContract.Calendars.CALENDAR_COLOR,
                    CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
                    CalendarContract.Calendars.SYNC_EVENTS,
                    CalendarContract.Calendars.VISIBLE
            };
            try (Cursor c = getContentResolver().query(CalendarContract.Calendars.CONTENT_URI, proj, null, null, null)) {
                while (c != null && c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("id", String.valueOf(c.getLong(0)));
                    o.put("name", str(c, 1));
                    o.put("account", str(c, 2));
                    o.put("color", String.format(Locale.US, "#%06X", 0xFFFFFF & c.getInt(3)));
                    o.put("canWrite", c.getInt(4) >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR);
                    o.put("synced", c.getInt(5) != 0);
                    o.put("visible", c.getInt(6) != 0);
                    out.put(o);
                }
            } catch (Exception e) {
                calError = message(e);
            }
            return out.toString();
        }

        @JavascriptInterface
        public String calendarError() {
            return calError;
        }

        @JavascriptInterface
        public String getEvents(String startMs, String endMs) {
            if (!calendarAllowed()) return "[]";
            Uri uri;
            try {
                Uri.Builder ub = CalendarContract.Instances.CONTENT_URI.buildUpon();
                ContentUris.appendId(ub, Long.parseLong(startMs));
                ContentUris.appendId(ub, Long.parseLong(endMs));
                uri = ub.build();
            } catch (Exception e) {
                calError = message(e);
                return "[]";
            }
            // Some phones do not expose every column; if the full query is refused, ask for the basics only.
            String[][] attempts = {EVENT_COLUMNS_FULL, EVENT_COLUMNS_BASIC};
            for (String[] proj : attempts) {
                boolean full = proj.length > EVENT_COLUMNS_BASIC.length;
                JSONArray out = new JSONArray();
                try (Cursor c = getContentResolver().query(uri, proj, null, null, CalendarContract.Instances.BEGIN + " ASC")) {
                    while (c != null && c.moveToNext()) {
                        if (full && !c.isNull(11) && c.getInt(11) == CalendarContract.Events.STATUS_CANCELED) continue;
                        JSONObject o = new JSONObject();
                        o.put("id", String.valueOf(c.getLong(0)));
                        o.put("begin", c.getLong(1));
                        o.put("end", c.getLong(2));
                        o.put("title", str(c, 3));
                        o.put("loc", str(c, 4));
                        o.put("desc", str(c, 5));
                        o.put("allDay", c.getInt(6) != 0);
                        o.put("calId", String.valueOf(c.getLong(7)));
                        // Without the extra columns we cannot tell a repeating event apart, so treat it as read-only.
                        o.put("recurring", !full || str(c, 8).length() > 0 || str(c, 9).length() > 0);
                        o.put("exception", !full || str(c, 10).length() > 0);
                        out.put(o);
                    }
                    if (full) calError = "";
                    return out.toString();
                } catch (Exception e) {
                    calError = message(e);
                }
            }
            return "[]";
        }

        private ContentValues eventValues(JSONObject o) throws Exception {
            boolean allDay = o.optBoolean("allDay", false);
            ContentValues v = new ContentValues();
            v.put(CalendarContract.Events.TITLE, o.optString("title", ""));
            v.put(CalendarContract.Events.EVENT_LOCATION, o.optString("loc", ""));
            v.put(CalendarContract.Events.DESCRIPTION, o.optString("desc", ""));
            v.put(CalendarContract.Events.DTSTART, o.getLong("begin"));
            v.put(CalendarContract.Events.DTEND, o.getLong("end"));
            v.put(CalendarContract.Events.ALL_DAY, allDay ? 1 : 0);
            v.put(CalendarContract.Events.EVENT_TIMEZONE, allDay ? "UTC" : TimeZone.getDefault().getID());
            return v;
        }

        @JavascriptInterface
        public String insertEvent(String json) {
            if (!calendarAllowed()) return "error:no permission";
            try {
                JSONObject o = new JSONObject(json);
                ContentValues v = eventValues(o);
                v.put(CalendarContract.Events.CALENDAR_ID, Long.parseLong(o.getString("calId")));
                Uri uri = getContentResolver().insert(CalendarContract.Events.CONTENT_URI, v);
                if (uri == null) return "error:insert failed";
                return uri.getLastPathSegment();
            } catch (Exception e) {
                return message(e);
            }
        }

        @JavascriptInterface
        public String updateEvent(String json) {
            if (!calendarAllowed()) return "error:no permission";
            try {
                JSONObject o = new JSONObject(json);
                Uri uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(o.getString("id")));
                int n = getContentResolver().update(uri, eventValues(o), null, null);
                return n > 0 ? "ok" : "error:not found";
            } catch (Exception e) {
                return message(e);
            }
        }

        @JavascriptInterface
        public String deleteEvent(String id) {
            if (!calendarAllowed()) return "error:no permission";
            try {
                Uri uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(id));
                getContentResolver().delete(uri, null, null);
                return "ok";
            } catch (Exception e) {
                return message(e);
            }
        }

        /** Remove a single occurrence of a repeating event; the rest of the series stays. */
        @JavascriptInterface
        public String deleteInstance(String eventId, String beginMs) {
            if (!calendarAllowed()) return "error:no permission";
            try {
                ContentValues v = new ContentValues();
                v.put(CalendarContract.Events.ORIGINAL_INSTANCE_TIME, Long.parseLong(beginMs));
                v.put(CalendarContract.Events.STATUS, CalendarContract.Events.STATUS_CANCELED);
                Uri.Builder ub = CalendarContract.Events.CONTENT_EXCEPTION_URI.buildUpon();
                ContentUris.appendId(ub, Long.parseLong(eventId));
                Uri uri = getContentResolver().insert(ub.build(), v);
                return uri == null ? "error:not removed" : "ok";
            } catch (Exception e) {
                return message(e);
            }
        }

        @JavascriptInterface
        public void openEvent(final String id, final String beginMs, final String endMs) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(id)));
                        i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, Long.parseLong(beginMs));
                        i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, Long.parseLong(endMs));
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        // ---------- reminders ----------

        @JavascriptInterface
        public void scheduleAlarms(String json) {
            Notifier.scheduleAll(MainActivity.this, json);
        }

        @JavascriptInterface
        public boolean notificationsEnabled() {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.areNotificationsEnabled();
        }

        @JavascriptInterface
        public boolean canScheduleExact() {
            if (Build.VERSION.SDK_INT < 31) return true;
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                        SharedPreferences prefs = getSharedPreferences("mashad", MODE_PRIVATE);
                        boolean askedBefore = prefs.getBoolean("askedNotifications", false);
                        if (!askedBefore || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                            prefs.edit().putBoolean("askedNotifications", true).apply();
                            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                            return;
                        }
                    }
                    showNotificationSettings();
                }
            });
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showNotificationSettings();
                }
            });
        }

        @JavascriptInterface
        public void testNotification() {
            Notifier.scheduleOne(MainActivity.this, 1999999999, System.currentTimeMillis() + 10000,
                    "בדיקת התראה", "אם ההודעה הזאת הגיעה, התזכורות עובדות.");
        }
    }

    private void showNotificationSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
        }
    }
}
