package com.mashad.planner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarms are wiped when the phone restarts or the app is updated; put them back. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Notifier.ensureChannel(context);
        Notifier.setFromStore(context);
    }
}
