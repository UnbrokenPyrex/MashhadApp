package com.mashad.planner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires when a reminder is due and shows it. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        Notifier.show(context, intent.getIntExtra("id", 1), title == null ? "" : title, text == null ? "" : text);
    }
}
